import  React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { Edit, Trash, CreditCard, Users, UserCircle } from 'lucide-react';
import { Expense } from '../../types';
import { formatCurrency, getCategoryIcon } from '../../lib/utils';
import Button from '../ui/Button';
import Avatar from '../ui/Avatar';

interface ExpenseItemProps {
  expense: Expense;
  currentUserId: string;
  onEdit: (expense: Expense) => void;
  onDelete: (id: string) => void;
}

const ExpenseItem: React.FC<ExpenseItemProps> = ({
  expense,
  currentUserId,
  onEdit,
  onDelete
}) => {
  const isPersonalExpense = !expense.groupId;
  const isPayer = expense.payerId === currentUserId;
  const currentUserParticipant = expense.participants.find(p => p.userId === currentUserId);
  
  // Get the participant amount for current user
  const userShare = currentUserParticipant?.shareAmount || 0;
  const userPaid = currentUserParticipant?.paidAmount || 0;
  const netAmount = userPaid - userShare;
  
  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this expense?')) {
      onDelete(expense.id);
    }
  };
  
  // Calculate whether the user is owed money or owes money
  const getStatusText = () => {
    if (netAmount > 0) {
      // The user paid more than their share
      const otherParticipants = expense.participants.filter(p => p.userId !== currentUserId);
      
      if (otherParticipants.length === 1) {
        return `${otherParticipants[0].user?.name} owes you ${formatCurrency(netAmount)}`;
      } else {
        return `You are owed ${formatCurrency(netAmount)}`;
      }
    } else if (netAmount < 0) {
      // The user paid less than their share
      const payer = expense.participants.find(p => p.paidAmount > 0 && p.userId !== currentUserId);
      
      if (payer) {
        return `You owe ${payer.user?.name} ${formatCurrency(Math.abs(netAmount))}`;
      } else {
        return `You owe ${formatCurrency(Math.abs(netAmount))}`;
      }
    }
    
    return 'Settled up';
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      className="bg-white rounded-xl shadow-sleek p-4 mb-4 border border-gray-100"
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary-50 to-primary-100 flex items-center justify-center text-lg mr-3 shadow-sm">
            {getCategoryIcon(expense.category)}
          </div>
          <div>
            <h3 className="font-medium text-gray-900">{expense.description}</h3>
            <p className="text-sm text-gray-500">
              {format(new Date(expense.createdAt), 'MMM d, yyyy')}
            </p>
          </div>
        </div>
        <div className={`text-lg font-semibold ${netAmount > 0 ? 'text-green-600' : netAmount < 0 ? 'text-red-600' : 'text-gray-600'}`}>
          {formatCurrency(Math.abs(netAmount))}
        </div>
      </div>
      
      <div className="flex items-center text-sm text-gray-600 mb-3">
        {isPersonalExpense ? (
          <div className="flex items-center">
            <UserCircle size={14} className="mr-1" />
            <span>Personal</span>
          </div>
        ) : (
          <div className="flex items-center">
            <Users size={14} className="mr-1" />
            <span>{expense.group?.name}</span>
          </div>
        )}
        
        <span className="mx-2">•</span>
        
        <div className="flex items-center">
          <Avatar 
            src={expense.payer?.avatarUrl}
            name={expense.payer?.name || 'Unknown'}
            size="xs"
            className="mr-1"
          />
          <span>
            {isPayer ? 'You paid' : `${expense.payer?.name} paid`} {formatCurrency(expense.amount)}
          </span>
        </div>
      </div>
      
      {netAmount !== 0 && (
        <div className="text-sm font-medium mb-3">
          <span className={netAmount > 0 ? 'text-green-600' : 'text-red-600'}>
            {getStatusText()}
          </span>
        </div>
      )}
      
      {expense.notes && (
        <div className="text-sm text-gray-600 border-t border-gray-100 pt-2 mb-3">
          {expense.notes}
        </div>
      )}
      
      <div className="flex space-x-2">
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => onEdit(expense)}
          leftIcon={<Edit size={14} />}
          className="text-gray-600"
        >
          Edit
        </Button>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={handleDelete}
          leftIcon={<Trash size={14} />}
          className="text-red-600"
        >
          Delete
        </Button>
      </div>
    </motion.div>
  );
};

export default ExpenseItem;
 