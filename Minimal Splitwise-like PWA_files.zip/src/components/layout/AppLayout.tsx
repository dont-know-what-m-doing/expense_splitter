import  React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Home, Users, Bell, User, UserCircle, ShoppingBag } from 'lucide-react';
import { useAuthStore } from '../../store/auth-store';
import { useNotificationStore } from '../../store/notification-store';
import Avatar from '../ui/Avatar';

interface AppLayoutProps {
  children: React.ReactNode;
  activePage: 'home' | 'groups' | 'friends' | 'notifications' | 'profile';
  onNavigate: (page: 'home' | 'groups' | 'friends' | 'notifications' | 'profile') => void;
}

const AppLayout: React.FC<AppLayoutProps> = ({ 
  children, 
  activePage, 
  onNavigate 
}) => {
  const { user } = useAuthStore();
  const { unreadCount, fetchNotifications } = useNotificationStore();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  
  useEffect(() => {
    if (user) {
      fetchNotifications(user.id);
    }
  }, [fetchNotifications, user]);
  
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      setIsScrolled(scrollTop > 10);
    };
    
    const contentElement = document.getElementById('app-content');
    if (contentElement) {
      contentElement.addEventListener('scroll', handleScroll);
    }
    
    return () => {
      if (contentElement) {
        contentElement.removeEventListener('scroll', handleScroll);
      }
    };
  }, []);
  
  const navigation = [
    { name: 'Home', icon: Home, page: 'home' as const },
    { name: 'Groups', icon: Users, page: 'groups' as const },
    { name: 'Friends', icon: UserCircle, page: 'friends' as const },
    { name: 'Notifications', icon: Bell, page: 'notifications' as const, badge: unreadCount },
    { name: 'Profile', icon: User, page: 'profile' as const }
  ];
  
  return (
    <div className="h-full flex flex-col bg-gray-50 text-gray-900">
      {/* Header */}
      <header 
        className={`py-2 px-4 flex items-center justify-between border-b border-gray-200 bg-white transition-shadow ${
          isScrolled ? 'shadow-sm' : ''
        }`}
      >
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="sm:hidden p-2 -ml-2 rounded-full text-gray-600 hover:bg-gray-100"
          >
            <Menu size={24} />
          </button>
          
          <div className="flex items-center">
            <div className="bg-primary-600 p-1.5 rounded-lg">
              <ShoppingBag className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-xl font-semibold ml-2 hidden sm:block">SplitEase</h1>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="hidden md:flex items-center space-x-1">
            {navigation.map((item) => (
              <button
                key={item.name}
                onClick={() => onNavigate(item.page)}
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-lg relative ${
                  activePage === item.page
                    ? 'bg-primary-50 text-primary-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <item.icon size={18} className="mr-1.5" />
                <span>{item.name}</span>
                {item.badge && item.badge > 0 && (
                  <span className="ml-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {item.badge > 9 ? '9+' : item.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
          
          {user && (
            <Avatar 
              src={user.avatarUrl} 
              name={user.name} 
              size="sm" 
              className="cursor-pointer"
              onClick={() => onNavigate('profile')}
            />
          )}
        </div>
      </header>
      
      {/* Mobile menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: -300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -300 }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="sm:hidden fixed inset-0 z-40 bg-black bg-opacity-50"
          >
            <div className="h-full w-3/4 max-w-xs bg-white shadow-xl flex flex-col">
              <div className="px-4 py-3 flex items-center justify-between border-b">
                <div className="flex items-center">
                  <div className="bg-primary-600 p-1.5 rounded-lg">
                    <ShoppingBag className="h-5 w-5 text-white" />
                  </div>
                  <span className="ml-2 font-semibold">SplitEase</span>
                </div>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 rounded-full text-gray-600 hover:bg-gray-100"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-2 flex-1 overflow-y-auto">
                {navigation.map((item) => (
                  <button
                    key={item.name}
                    onClick={() => {
                      onNavigate(item.page);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`flex items-center px-3 py-2 text-base font-medium rounded-md w-full ${
                      activePage === item.page
                        ? 'bg-primary-50 text-primary-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    <item.icon size={20} className="mr-3" />
                    <span>{item.name}</span>
                    {item.badge && item.badge > 0 && (
                      <span className="ml-auto bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {item.badge > 9 ? '9+' : item.badge}
                      </span>
                    )}
                  </button>
                ))}
              </div>
              
              {user && (
                <div className="border-t border-gray-200 p-4">
                  <div className="flex items-center">
                    <Avatar src={user.avatarUrl} name={user.name} size="sm" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-900">{user.name}</p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Main content */}
      <main 
        id="app-content"
        className="flex-1 overflow-y-auto p-4 sm:px-6 md:px-8"
      >
        <div className="mx-auto max-w-3xl">
          {children}
        </div>
      </main>
      
      {/* Mobile bottom navbar */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 bg-white border-t border-gray-200 flex items-center justify-around p-1 z-10">
        {navigation.map((item) => (
          <button
            key={item.name}
            onClick={() => onNavigate(item.page)}
            className={`flex flex-col items-center p-2 rounded-lg flex-1 relative ${
              activePage === item.page
                ? 'text-primary-600'
                : 'text-gray-600'
            }`}
          >
            <item.icon size={20} />
            <span className="text-xs mt-1">{item.name}</span>
            {item.badge && item.badge > 0 && (
              <span className="absolute top-0 right-1/4 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center text-xs">
                {item.badge > 9 ? '9+' : item.badge}
              </span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
};

export default AppLayout;
 