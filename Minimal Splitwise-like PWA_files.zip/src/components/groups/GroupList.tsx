import  React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, UserPlus, Search, X } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import GroupItem from './GroupItem';
import GroupForm from './GroupForm';
import MemberManagement from './MemberManagement';
import Modal from '../ui/Modal';
import { useGroupStore } from '../../store/group-store';
import { useExpenseStore } from '../../store/expense-store';
import { Group } from '../../types';

interface GroupListProps {
  onViewGroupExpenses: (groupId: string) => void;
}

const GroupList: React.FC<GroupListProps> = ({ onViewGroupExpenses }) => {
  const { groups, fetchGroups, deleteGroup, loading } = useGroupStore();
  const { exportExpensesCsv } = useExpenseStore();
  
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredGroups, setFilteredGroups] = useState<Group[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showMembersModal, setShowMembersModal] = useState(false);
  
  useEffect(() => {
    fetchGroups();
  }, [fetchGroups]);
  
  useEffect(() => {
    if (!searchTerm) {
      setFilteredGroups(groups);
    } else {
      const filtered = groups.filter(group => 
        group.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredGroups(filtered);
    }
  }, [groups, searchTerm]);
  
  const handleEditGroup = (group: Group) => {
    setSelectedGroup(group);
    setShowEditModal(true);
  };
  
  const handleExport = (groupId: string) => {
    exportExpensesCsv(groupId);
  };
  
  const handleManageMembers = (group: Group) => {
    setSelectedGroup(group);
    setShowMembersModal(true);
  };
  
  return (
    <div>
      <div className="mb-4 sticky top-0 z-10">
        <Input
          placeholder="Search groups..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          icon={<Search size={18} />}
          className={searchTerm ? "pr-10" : ""}
        />
        {searchTerm && (
          <button
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            onClick={() => setSearchTerm('')}
          >
            <X size={16} />
          </button>
        )}
      </div>
      
      <div className="mb-4">
        <Button
          fullWidth
          leftIcon={<Plus size={18} />}
          onClick={() => setShowAddModal(true)}
          className="shadow-sm"
        >
          Create New Group
        </Button>
      </div>
      
      {loading && <div className="text-center py-8">Loading groups...</div>}
      
      {!loading && filteredGroups.length === 0 && (
        <div className="text-center py-10 bg-gray-50 rounded-xl border border-gray-200">
          <div className="mb-2 text-gray-400">
            <img
              src="https://images.unsplash.com/photo-1471086569966-db3eebc25a59?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxtaW5pbWFsJTIwZXhwZW5zZSUyMHNoYXJpbmclMjBhcHAlMjBVSSUyMG1vYmlsZXxlbnwwfHx8fDE3NDc3MjM2OTB8MA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800"
              alt="No groups"
              className="w-32 h-32 object-contain mx-auto rounded-lg mb-4"
            />
          </div>
          <p className="text-gray-500 mb-4">
            {searchTerm 
              ? 'No groups match your search' 
              : "You don't have any groups yet"}
          </p>
          <div className="flex justify-center">
            {searchTerm ? (
              <Button
                onClick={() => setSearchTerm('')}
                variant="outline"
              >
                Clear search
              </Button>
            ) : (
              <Button
                onClick={() => setShowAddModal(true)}
                leftIcon={<Plus size={16} />}
              >
                Create your first group
              </Button>
            )}
          </div>
        </div>
      )}
      
      <AnimatePresence>
        {filteredGroups.map(group => (
          <GroupItem
            key={group.id}
            group={group}
            onEdit={handleEditGroup}
            onDelete={deleteGroup}
            onViewExpenses={onViewGroupExpenses}
            onExport={handleExport}
            onManageMembers={handleManageMembers}
          />
        ))}
      </AnimatePresence>
      
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Create Group"
      >
        <GroupForm
          onSuccess={() => setShowAddModal(false)}
          onCancel={() => setShowAddModal(false)}
        />
      </Modal>
      
      <Modal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        title="Edit Group"
      >
        {selectedGroup && (
          <GroupForm
            group={selectedGroup}
            onSuccess={() => setShowEditModal(false)}
            onCancel={() => setShowEditModal(false)}
          />
        )}
      </Modal>
      
      <Modal
        isOpen={showMembersModal}
        onClose={() => setShowMembersModal(false)}
        title={selectedGroup ? `Manage Members - ${selectedGroup.name}` : 'Manage Members'}
      >
        {selectedGroup && (
          <MemberManagement
            group={selectedGroup}
            onClose={() => setShowMembersModal(false)}
          />
        )}
      </Modal>
    </div>
  );
};

export default GroupList;
 