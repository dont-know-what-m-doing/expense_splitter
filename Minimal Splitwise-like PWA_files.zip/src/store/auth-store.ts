import  { create } from 'zustand';
import { User } from '../types';

interface AuthState {
  user: User | null;
  session: any | null;
  loading: boolean;
  error: string | null;
  initialized: boolean;
  login: (email: string, password: string, adminCode: string) => Promise<void>;
  register: (email: string, password: string, adminCode: string, name: string) => Promise<void>;
  logout: () => Promise<void>;
  initialize: () => Promise<void>;
}

// Demo admin code for development
const DEMO_ADMIN_CODE = '123456';

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  session: null,
  loading: false,
  error: null,
  initialized: false,

  login: async (email, password, adminCode) => {
    set({ loading: true, error: null });
    
    try {
      // Validate admin code
      if (adminCode !== DEMO_ADMIN_CODE) {
        throw new Error('Invalid admin code');
      }
      
      // For demo purposes, we'll simulate authentication with a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Demo user credentials check
      if (email === 'demo@example.com' && password === 'password') {
        const mockUser = {
          id: 'user-demo',
          email: 'demo@example.com',
          name: 'Demo User',
          avatarUrl: null
        };
        
        // Save to localStorage for demo persistence
        localStorage.setItem('splitease-user', JSON.stringify(mockUser));
        localStorage.setItem('splitease-session', JSON.stringify({ expires_at: Date.now() + 86400000 }));
        
        set({ 
          user: mockUser, 
          session: { expires_at: Date.now() + 86400000 },
          loading: false 
        });
      } else {
        throw new Error('Invalid email or password');
      }
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  register: async (email, password, adminCode, name) => {
    set({ loading: true, error: null });
    
    try {
      // Validate admin code
      if (adminCode !== DEMO_ADMIN_CODE) {
        throw new Error('Invalid admin code');
      }
      
      // For demo purposes, we'll simulate registration with a delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockUser = {
        id: `user-${Date.now()}`,
        email,
        name,
        avatarUrl: null
      };
      
      // Save to localStorage for demo persistence
      localStorage.setItem('splitease-user', JSON.stringify(mockUser));
      localStorage.setItem('splitease-session', JSON.stringify({ expires_at: Date.now() + 86400000 }));
      
      set({ 
        user: mockUser, 
        session: { expires_at: Date.now() + 86400000 },
        loading: false 
      });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  logout: async () => {
    set({ loading: true });
    
    try {
      // For demo purposes, we'll simulate logout with a delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Clear localStorage
      localStorage.removeItem('splitease-user');
      localStorage.removeItem('splitease-session');
      
      set({ user: null, session: null, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  initialize: async () => {
    if (get().initialized) return;
    
    set({ loading: true });
    
    try {
      // Check localStorage for user data in demo mode
      const storedUser = localStorage.getItem('splitease-user');
      const storedSession = localStorage.getItem('splitease-session');
      
      if (storedUser && storedSession) {
        const user = JSON.parse(storedUser);
        const session = JSON.parse(storedSession);
        
        // Check if session is expired
        if (session.expires_at > Date.now()) {
          set({ user, session, loading: false, initialized: true });
          return;
        }
      }
      
      set({ user: null, session: null, loading: false, initialized: true });
    } catch (error: any) {
      set({ error: error.message, loading: false, initialized: true });
    }
  }
}));
 