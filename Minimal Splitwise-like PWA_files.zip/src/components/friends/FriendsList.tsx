import  React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Search, UserPlus, Mail, RefreshCw } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Modal from '../ui/Modal';
import Avatar from '../ui/Avatar';
import { useAuthStore } from '../../store/auth-store';
import { User } from '../../types';
import { formatCurrency } from '../../lib/utils';

interface FriendsListProps {
  onViewFriendExpenses: (friendId: string) => void;
}

const FriendsList: React.FC<FriendsListProps> = ({ onViewFriendExpenses }) => {
  const { user } = useAuthStore();
  const [friends, setFriends] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddFriendModal, setShowAddFriendModal] = useState(false);
  const [friendEmail, setFriendEmail] = useState('');
  const [friendPhone, setFriendPhone] = useState('');
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch friends data
    const fetchFriends = async () => {
      setLoading(true);
      
      // Mock friends data for development
      setTimeout(() => {
        const mockFriends = [
          { 
            id: 'user-1',
            name: 'Alex Johnson',
            email: 'alex@example.com',
            balance: 45.50,
            lastActivity: new Date().toISOString()
          },
          { 
            id: 'user-2',
            name: 'Sam Wilson',
            email: 'sam@example.com',
            balance: -120.00,
            lastActivity: new Date(Date.now() - 86400000).toISOString()
          },
          { 
            id: 'user-3',
            name: 'Jordan Lee',
            email: 'jordan@example.com',
            balance: 0,
            lastActivity: new Date(Date.now() - 86400000 * 3).toISOString()
          }
        ];
        
        setFriends(mockFriends);
        setLoading(false);
      }, 800);
    };
    
    fetchFriends();
  }, []);
  
  const handleSearchFriend = (term: string) => {
    setSearchTerm(term);
    
    if (term.length < 3) {
      setSearchResults([]);
      return;
    }
    
    setIsSearching(true);
    
    // Mock search results for development
    setTimeout(() => {
      const results = [
        { id: 'user-4', name: 'Chris Taylor', email: 'chris@example.com' },
        { id: 'user-5', name: 'Morgan Jones', email: 'morgan@example.com' },
        { id: 'user-6', name: 'Jamie Smith', email: 'jamie@example.com' }
      ].filter(u => 
        u.name.toLowerCase().includes(term.toLowerCase()) || 
        u.email.toLowerCase().includes(term.toLowerCase())
      );
      
      setSearchResults(results);
      setIsSearching(false);
    }, 500);
  };
  
  const handleAddFriend = async () => {
    if (!friendEmail && !friendPhone) {
      setError('Please enter an email or phone number');
      return;
    }
    
    if (friendEmail && !friendEmail.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }
    
    setError('');
    
    // Mock adding a friend
    setTimeout(() => {
      const newFriend = {
        id: `user-${Date.now()}`,
        name: friendEmail.split('@')[0] || 'New Friend',
        email: friendEmail,
        balance: 0,
        lastActivity: new Date().toISOString()
      };
      
      setFriends([newFriend, ...friends]);
      setFriendEmail('');
      setFriendPhone('');
      setShowAddFriendModal(false);
    }, 500);
  };
  
  const handleAddFromSearch = (friend: User) => {
    const existingFriend = friends.find(f => f.id === friend.id);
    
    if (!existingFriend) {
      const newFriend = {
        ...friend,
        balance: 0,
        lastActivity: new Date().toISOString()
      };
      
      setFriends([newFriend, ...friends]);
    }
    
    setSearchTerm('');
    setSearchResults([]);
  };
  
  const filteredFriends = searchTerm
    ? friends.filter(friend => 
        friend.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        friend.email.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : friends;
  
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Friends</h1>
        <Button
          onClick={() => setShowAddFriendModal(true)}
          leftIcon={<UserPlus size={18} />}
        >
          Add Friend
        </Button>
      </div>
      
      <div className="mb-4">
        <Input
          placeholder="Search friends"
          value={searchTerm}
          onChange={(e) => handleSearchFriend(e.target.value)}
          icon={<Search size={18} />}
          clearable
          onClear={() => setSearchTerm('')}
        />
      </div>
      
      {loading ? (
        <div className="flex justify-center py-10">
          <RefreshCw size={24} className="animate-spin text-primary-500" />
        </div>
      ) : filteredFriends.length === 0 ? (
        <div className="text-center py-10 bg-gray-50 rounded-xl border border-gray-200">
          <div className="mb-4">
            <UserPlus size={48} className="mx-auto text-gray-400" />
          </div>
          <p className="text-gray-500 mb-4">You don't have any friends yet</p>
          <Button 
            onClick={() => setShowAddFriendModal(true)}
            leftIcon={<Plus size={16} />}
            variant="outline"
            size="sm"
          >
            Add a friend
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {searchResults.length > 0 && (
            <div className="mb-4 border rounded-lg overflow-hidden">
              <div className="bg-gray-50 px-4 py-2 border-b">
                <h3 className="text-sm font-medium text-gray-700">Search Results</h3>
              </div>
              <div className="divide-y">
                {searchResults.map(result => (
                  <div key={result.id} className="p-3 flex items-center justify-between">
                    <div className="flex items-center">
                      <Avatar src={result.avatarUrl} name={result.name} size="sm" />
                      <div className="ml-3">
                        <div className="text-sm font-medium">{result.name}</div>
                        <div className="text-xs text-gray-500">{result.email}</div>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleAddFromSearch(result)}
                    >
                      Add
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {filteredFriends.map(friend => (
            <motion.div
              key={friend.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ y: -2 }}
              transition={{ duration: 0.2 }}
              className="bg-white p-4 rounded-xl shadow-soft border border-gray-100"
              onClick={() => onViewFriendExpenses(friend.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Avatar 
                    src={friend.avatarUrl} 
                    name={friend.name} 
                    size="md"
                  />
                  <div>
                    <h3 className="font-medium">{friend.name}</h3>
                    <p className="text-sm text-gray-500">{friend.email}</p>
                  </div>
                </div>
                
                <div className={`text-right ${
                  friend.balance > 0 ? 'text-green-600' : 
                  friend.balance < 0 ? 'text-red-600' : 'text-gray-600'
                }`}>
                  <p className="font-semibold">{formatCurrency(Math.abs(friend.balance))}</p>
                  <p className="text-xs">
                    {friend.balance > 0 
                      ? 'they owe you' 
                      : friend.balance < 0 
                        ? 'you owe them' 
                        : 'settled up'}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
      
      <Modal
        isOpen={showAddFriendModal}
        onClose={() => setShowAddFriendModal(false)}
        title="Add a Friend"
      >
        <div className="space-y-4">
          <Input
            label="Email"
            placeholder="friend@example.com"
            value={friendEmail}
            onChange={(e) => setFriendEmail(e.target.value)}
            icon={<Mail size={18} />}
            type="email"
          />
          
          <Input
            label="Phone Number (optional)"
            placeholder="+1 (555) 123-4567"
            value={friendPhone}
            onChange={(e) => setFriendPhone(e.target.value)}
            type="tel"
          />
          
          {error && (
            <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100">
              {error}
            </div>
          )}
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button
              variant="outline"
              onClick={() => setShowAddFriendModal(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddFriend}
            >
              Send Invitation
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default FriendsList;
 