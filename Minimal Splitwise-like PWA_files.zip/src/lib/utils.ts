import  { ExpenseParticipant } from '../types';

export const supabaseUrl = 'https://placeholder-project.supabase.co';

export function formatCurrency(amount: number): string {
  return `₹${amount.toFixed(2)}`;
}

export function useOnlineStatus(): boolean {
  if (typeof navigator === 'undefined') return true;
  return navigator.onLine;
}

export function calculateShareAmount(amount: number, numberOfPeople: number): number {
  if (numberOfPeople <= 0) return 0;
  return Math.round((amount / numberOfPeople) * 100) / 100; // Round to 2 decimal places
}

export function getCategoryIcon(category: string): string {
  const icons: { [key: string]: string } = {
    'Food & Drink': '🍔',
    'Groceries': '🛒',
    'Transportation': '🚗',
    'Housing': '🏠',
    'Utilities': '💡',
    'Entertainment': '🎬',
    'Travel': '✈️',
    'Shopping': '🛍️',
    'Health': '💊',
    'Education': '📚',
    'Gifts': '🎁',
    'Other': '📝'
  };
  
  return icons[category] || '📝';
}

// Generate consistent avatar colors based on name
export function generateAvatarColor(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  const hue = Math.abs(hash % 360);
  return `hsl(${hue}, 70%, 60%)`;
}

// Calculate balances for all participants
export function calculateBalances(participants: ExpenseParticipant[]): Array<{userId: string, amount: number}> {
  const balances = new Map<string, number>();
  
  participants.forEach(participant => {
    const userId = participant.userId;
    const shareAmount = participant.shareAmount;
    const paidAmount = participant.paidAmount;
    const netAmount = paidAmount - shareAmount; // Positive means they are owed money
    
    const currentBalance = balances.get(userId) || 0;
    balances.set(userId, currentBalance + netAmount);
  });
  
  return Array.from(balances.entries()).map(([userId, amount]) => ({ userId, amount }));
}

// Simplify debts to minimize the number of transactions
export function simplifyDebts(balances: Array<{userId: string, amount: number}>): Array<{from: string, to: string, amount: number}> {
  // Split into creditors (amount > 0) and debtors (amount < 0)
  const creditors = balances.filter(b => b.amount > 0).sort((a, b) => b.amount - a.amount);
  const debtors = balances.filter(b => b.amount < 0).sort((a, b) => a.amount - b.amount);
  
  // For users who are neither debtors nor creditors
  if (creditors.length === 0 || debtors.length === 0) {
    return [];
  }
  
  const transactions: Array<{from: string, to: string, amount: number}> = [];
  
  let creditorIndex = 0;
  let debtorIndex = 0;
  
  while (creditorIndex < creditors.length && debtorIndex < debtors.length) {
    const creditor = creditors[creditorIndex];
    const debtor = debtors[debtorIndex];
    
    // Use the smallest absolute value to create a transaction
    const transactionAmount = Math.min(creditor.amount, Math.abs(debtor.amount));
    
    if (transactionAmount > 0) {
      transactions.push({
        from: debtor.userId,
        to: creditor.userId,
        amount: transactionAmount
      });
    }
    
    // Update remaining balances
    creditor.amount -= transactionAmount;
    debtor.amount += transactionAmount;
    
    // Move to next creditor or debtor if their balance is settled
    if (Math.abs(creditor.amount) < 0.01) creditorIndex++;
    if (Math.abs(debtor.amount) < 0.01) debtorIndex++;
  }
  
  return transactions;
}

// Helper for classnames
export function cn(...classes: (string | boolean | undefined | null)[]) {
  return classes.filter(Boolean).join(' ');
}
 