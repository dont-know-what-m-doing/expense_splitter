import  React from 'react';
import { User } from 'lucide-react';
import { cn } from '../../lib/utils-ui';
import { generateAvatarColor } from '../../lib/utils';

interface AvatarProps {
  src?: string | null;
  name: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  borderColor?: string;
  className?: string;
  onClick?: () => void;
}

const Avatar: React.FC<AvatarProps> = ({
  src,
  name,
  size = 'md',
  borderColor,
  className,
  onClick
}) => {
  const [imgError, setImgError] = React.useState(false);
  
  const sizes = {
    xs: 'w-6 h-6 text-[10px]',
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
    xl: 'w-16 h-16 text-lg'
  };
  
  const getInitials = (name: string) => {
    const words = name.trim().split(' ');
    if (words.length === 1) {
      return words[0].charAt(0).toUpperCase();
    }
    return (words[0].charAt(0) + words[words.length - 1].charAt(0)).toUpperCase();
  };
  
  const backgroundColor = generateAvatarColor(name);
  
  const handleError = () => {
    setImgError(true);
  };
  
  return (
    <div 
      className={cn(
        'relative flex items-center justify-center rounded-full overflow-hidden shrink-0 select-none',
        sizes[size],
        borderColor && 'ring-2',
        borderColor ? `ring-${borderColor}` : '',
        onClick && 'cursor-pointer',
        className
      )}
      style={{ backgroundColor: !src || imgError ? backgroundColor : undefined }}
      onClick={onClick}
    >
      {src && !imgError ? (
        <img
          src={src}
          alt={name}
          className="w-full h-full object-cover"
          onError={handleError}
        />
      ) : (
        <span className="font-semibold text-white">{getInitials(name)}</span>
      )}
    </div>
  );
};

export default Avatar;
 