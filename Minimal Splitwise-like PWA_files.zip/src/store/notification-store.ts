import  { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { Notification } from '../types';

interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  loading: boolean;
  error: string | null;
  fetchNotifications: (userId: string) => Promise<void>;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: (userId: string) => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt'>) => Promise<void>;
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: [],
  unreadCount: 0,
  loading: false,
  error: null,

  fetchNotifications: async (userId) => {
    set({ loading: true, error: null });
    
    try {
      // For demo purposes, we're simulating fetching notifications with a delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Check for stored notifications in localStorage
      const storedNotifications = localStorage.getItem('splitease-notifications');
      let notifications: Notification[] = [];
      
      if (storedNotifications) {
        notifications = JSON.parse(storedNotifications);
      } else {
        // If no stored notifications, use initial demo data
        notifications = [
          {
            id: 'notif-1',
            userId,
            message: 'Alex added you to "Weekend Trip" group',
            read: false,
            createdAt: new Date().toISOString(),
            groupId: 'group-1'
          },
          {
            id: 'notif-2',
            userId,
            message: 'Sam added a new expense "Dinner at Restaurant"',
            read: true,
            createdAt: new Date(Date.now() - 86400000).toISOString(),
            expenseId: 'expense-1'
          },
          {
            id: 'notif-3',
            userId,
            message: 'You were added to an expense of ₹500',
            read: false,
            createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
            expenseId: 'expense-2'
          }
        ];
        
        // Save to localStorage
        localStorage.setItem('splitease-notifications', JSON.stringify(notifications));
      }
      
      // Filter notifications for this user
      const userNotifications = notifications.filter(notif => notif.userId === userId);
      
      // Calculate unread count
      const unreadCount = userNotifications.filter(notif => !notif.read).length;
      
      set({ 
        notifications: userNotifications, 
        unreadCount,
        loading: false 
      });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  markAsRead: async (id) => {
    set({ loading: true, error: null });
    
    try {
      const { notifications } = get();
      
      const notificationIndex = notifications.findIndex((n) => n.id === id);
      if (notificationIndex === -1) {
        throw new Error('Notification not found');
      }
      
      const updatedNotification = {
        ...notifications[notificationIndex],
        read: true
      };
      
      const updatedNotifications = [...notifications];
      updatedNotifications[notificationIndex] = updatedNotification;
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Update in localStorage
      // Note: This is a bit complex since we need to update just this user's notification
      // while preserving others. In a real app with a proper backend, this would be simpler.
      const storedNotifications = localStorage.getItem('splitease-notifications');
      if (storedNotifications) {
        const allNotifications = JSON.parse(storedNotifications);
        const allUpdatedNotifications = allNotifications.map((n: Notification) => 
          n.id === id ? { ...n, read: true } : n
        );
        localStorage.setItem('splitease-notifications', JSON.stringify(allUpdatedNotifications));
      }
      
      // Calculate new unread count
      const unreadCount = updatedNotifications.filter(notif => !notif.read).length;
      
      set({ 
        notifications: updatedNotifications, 
        unreadCount,
        loading: false 
      });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  markAllAsRead: async (userId) => {
    set({ loading: true, error: null });
    
    try {
      const { notifications } = get();
      
      const updatedNotifications = notifications.map(notif => ({
        ...notif,
        read: true
      }));
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Update in localStorage
      const storedNotifications = localStorage.getItem('splitease-notifications');
      if (storedNotifications) {
        const allNotifications = JSON.parse(storedNotifications);
        const allUpdatedNotifications = allNotifications.map((n: Notification) => 
          n.userId === userId ? { ...n, read: true } : n
        );
        localStorage.setItem('splitease-notifications', JSON.stringify(allUpdatedNotifications));
      }
      
      set({ 
        notifications: updatedNotifications, 
        unreadCount: 0,
        loading: false 
      });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  deleteNotification: async (id) => {
    set({ loading: true, error: null });
    
    try {
      const { notifications } = get();
      
      const updatedNotifications = notifications.filter((n) => n.id !== id);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Update in localStorage
      const storedNotifications = localStorage.getItem('splitease-notifications');
      if (storedNotifications) {
        const allNotifications = JSON.parse(storedNotifications);
        const allUpdatedNotifications = allNotifications.filter((n: Notification) => n.id !== id);
        localStorage.setItem('splitease-notifications', JSON.stringify(allUpdatedNotifications));
      }
      
      // Calculate new unread count
      const unreadCount = updatedNotifications.filter(notif => !notif.read).length;
      
      set({ 
        notifications: updatedNotifications, 
        unreadCount,
        loading: false 
      });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  addNotification: async (notification) => {
    set({ loading: true, error: null });
    
    try {
      const { notifications } = get();
      
      const newNotification: Notification = {
        id: uuidv4(),
        createdAt: new Date().toISOString(),
        ...notification
      };
      
      const updatedNotifications = [newNotification, ...notifications];
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Update in localStorage
      const storedNotifications = localStorage.getItem('splitease-notifications');
      let allUpdatedNotifications: Notification[];
      
      if (storedNotifications) {
        const allNotifications = JSON.parse(storedNotifications);
        allUpdatedNotifications = [newNotification, ...allNotifications];
      } else {
        allUpdatedNotifications = [newNotification];
      }
      
      localStorage.setItem('splitease-notifications', JSON.stringify(allUpdatedNotifications));
      
      // Calculate new unread count
      const unreadCount = updatedNotifications.filter(notif => !notif.read).length;
      
      set({ 
        notifications: updatedNotifications, 
        unreadCount,
        loading: false 
      });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  }
}));
 