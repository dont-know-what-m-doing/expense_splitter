export  interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          name: string;
          email: string;
          avatar_url?: string;
        };
        Insert: {
          id: string;
          name: string;
          email: string;
          avatar_url?: string;
        };
        Update: {
          id?: string;
          name?: string;
          email?: string;
          avatar_url?: string;
        };
      };
      groups: {
        Row: {
          id: string;
          name: string;
          created_at: string;
          created_by: string;
        };
        Insert: {
          id?: string;
          name: string;
          created_at?: string;
          created_by: string;
        };
        Update: {
          id?: string;
          name?: string;
          created_at?: string;
          created_by?: string;
        };
      };
      group_members: {
        Row: {
          id: string;
          group_id: string;
          user_id: string;
        };
        Insert: {
          id?: string;
          group_id: string;
          user_id: string;
        };
        Update: {
          id?: string;
          group_id?: string;
          user_id?: string;
        };
      };
      expenses: {
        Row: {
          id: string;
          created_at: string;
          amount: number;
          description: string;
          payer_id: string;
          group_id?: string;
          category: string;
          notes?: string;
        };
        Insert: {
          id?: string;
          created_at?: string;
          amount: number;
          description: string;
          payer_id: string;
          group_id?: string;
          category: string;
          notes?: string;
        };
        Update: {
          id?: string;
          created_at?: string;
          amount?: number;
          description?: string;
          payer_id?: string;
          group_id?: string;
          category?: string;
          notes?: string;
        };
      };
      expense_participants: {
        Row: {
          id: string;
          expense_id: string;
          user_id: string;
          share_amount: number;
          paid_amount: number;
        };
        Insert: {
          id?: string;
          expense_id: string;
          user_id: string;
          share_amount: number;
          paid_amount: number;
        };
        Update: {
          id?: string;
          expense_id?: string;
          user_id?: string;
          share_amount?: number;
          paid_amount?: number;
        };
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          message: string;
          read: boolean;
          created_at: string;
          expense_id?: string;
          group_id?: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          message: string;
          read?: boolean;
          created_at?: string;
          expense_id?: string;
          group_id?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          message?: string;
          read?: boolean;
          created_at?: string;
          expense_id?: string;
          group_id?: string;
        };
      };
    };
  };
}
 