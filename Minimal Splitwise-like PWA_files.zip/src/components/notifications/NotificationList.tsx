import  React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { CheckCircle, Trash2, RefreshCw } from 'lucide-react';
import { useAuthStore } from '../../store/auth-store';
import { useNotificationStore } from '../../store/notification-store';
import Button from '../ui/Button';
import { Notification } from '../../types';

const NotificationList: React.FC = () => {
  const { user } = useAuthStore();
  const { 
    notifications, 
    unreadCount, 
    loading, 
    error, 
    fetchNotifications, 
    markAsRead, 
    markAllAsRead, 
    deleteNotification 
  } = useNotificationStore();
  
  useEffect(() => {
    if (user) {
      fetchNotifications(user.id);
    }
  }, [user, fetchNotifications]);
  
  const handleMarkAsRead = (notificationId: string) => {
    markAsRead(notificationId);
  };
  
  const handleMarkAllAsRead = () => {
    if (user) {
      markAllAsRead(user.id);
    }
  };
  
  const handleDelete = (notificationId: string) => {
    deleteNotification(notificationId);
  };
  
  if (!user) return null;
  
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
        
        {unreadCount > 0 && (
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleMarkAllAsRead}
          >
            Mark all as read
          </Button>
        )}
      </div>
      
      {loading ? (
        <div className="flex justify-center py-10">
          <RefreshCw size={24} className="animate-spin text-primary-500" />
        </div>
      ) : error ? (
        <div className="text-center py-8 bg-red-50 rounded-lg border border-red-200">
          <p className="text-red-600">{error}</p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => fetchNotifications(user.id)}
            className="mt-4"
          >
            Try Again
          </Button>
        </div>
      ) : notifications.length === 0 ? (
        <div className="text-center py-10 bg-gray-50 rounded-lg border border-gray-200">
          <p className="text-gray-500">You don't have any notifications</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((notification) => (
            <NotificationItem
              key={notification.id}
              notification={notification}
              onMarkAsRead={handleMarkAsRead}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
};

interface NotificationItemProps {
  notification: Notification;
  onMarkAsRead: (id: string) => void;
  onDelete: (id: string) => void;
}

const NotificationItem: React.FC<NotificationItemProps> = ({
  notification,
  onMarkAsRead,
  onDelete
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      className={`p-4 rounded-lg border ${notification.read ? 'bg-white border-gray-200' : 'bg-primary-50 border-primary-200'}`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className={`${notification.read ? 'text-gray-800' : 'text-gray-900 font-medium'}`}>
            {notification.message}
          </p>
          <p className="text-xs text-gray-500 mt-1">
            {format(new Date(notification.createdAt), 'MMM d, yyyy • h:mm a')}
          </p>
        </div>
        <div className="flex ml-4">
          {!notification.read && (
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onMarkAsRead(notification.id);
              }}
              className="p-1 rounded-full hover:bg-gray-100 text-primary-500"
            >
              <CheckCircle size={18} />
            </button>
          )}
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onDelete(notification.id);
            }}
            className="p-1 rounded-full hover:bg-gray-100 text-red-500 ml-1"
          >
            <Trash2 size={18} />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default NotificationList;
 