import  React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CreditCard, Download, Users, RefreshCw } from 'lucide-react';
import { useExpenseStore } from '../../store/expense-store';
import { useAuthStore } from '../../store/auth-store';
import { formatCurrency, calculateBalances, simplifyDebts } from '../../lib/utils';
import Button from '../ui/Button';
import Avatar from '../ui/Avatar';
import { Expense } from '../../types';

interface BalanceSummaryProps {
  groupId?: string;
  friendId?: string;
}

const BalanceSummary: React.FC<BalanceSummaryProps> = ({ groupId, friendId }) => {
  const { user } = useAuthStore();
  const { expenses, exportExpensesCsv } = useExpenseStore();
  
  const [relevantExpenses, setRelevantExpenses] = useState<Expense[]>([]);
  const [simplifiedDebts, setSimplifiedDebts] = useState<any[]>([]);
  const [totalBalance, setTotalBalance] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    if (!user) return;
    
    setIsLoading(true);
    
    // Filter expenses
    let filtered = [...expenses];
    
    if (groupId) {
      filtered = filtered.filter(e => e.groupId === groupId);
    }
    
    if (friendId) {
      filtered = filtered.filter(e => 
        e.participants.some(p => p.userId === friendId) && 
        e.participants.some(p => p.userId === user.id)
      );
    }
    
    setRelevantExpenses(filtered);
    
    // Calculate balances
    const allParticipants = filtered.flatMap(e => e.participants);
    const balances = calculateBalances(allParticipants);
    
    // Get current user's balance
    const userBalance = balances.find(b => b.userId === user.id);
    setTotalBalance(userBalance?.amount || 0);
    
    // Calculate simplified debts
    const debts = simplifyDebts(balances);
    
    // Filter to only show debts relevant to current user or for the specific friend
    let relevantDebts = debts;
    
    if (friendId) {
      relevantDebts = debts.filter(
        debt => (debt.from === user.id && debt.to === friendId) || 
               (debt.from === friendId && debt.to === user.id)
      );
    } else {
      relevantDebts = debts.filter(
        debt => debt.from === user.id || debt.to === user.id
      );
    }
    
    setSimplifiedDebts(relevantDebts);
    setIsLoading(false);
  }, [expenses, groupId, friendId, user]);
  
  const handleExport = () => {
    exportExpensesCsv(groupId, friendId || user?.id);
  };
  
  if (!user) return null;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="bg-white rounded-xl shadow-sleek mb-6 overflow-hidden border border-gray-100"
    >
      <div className="p-4 sm:p-5">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Balance Summary</h2>
          <Button
            variant="outline"
            size="sm"
            leftIcon={<Download size={16} />}
            onClick={handleExport}
          >
            Export
          </Button>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center py-8">
            <RefreshCw size={24} className="animate-spin text-primary-500" />
          </div>
        ) : (
          <>
            <div className="p-4 rounded-xl bg-gradient-to-r from-primary-50 to-primary-100 mb-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-gray-700">Your total balance:</span>
                <span className={`text-xl font-semibold ${
                  totalBalance > 0 ? 'text-green-600' : 
                  totalBalance < 0 ? 'text-red-600' : 'text-gray-600'
                }`}>
                  {formatCurrency(Math.abs(totalBalance))}
                  {totalBalance !== 0 && (
                    <span className="text-sm ml-1">
                      {totalBalance > 0 ? '(you are owed)' : '(you owe)'}
                    </span>
                  )}
                </span>
              </div>
            </div>
            
            {simplifiedDebts.length > 0 ? (
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-3">Summary of balances</h3>
                <div className="space-y-3">
                  {simplifiedDebts.map((debt, index) => {
                    const otherUserId = debt.from === user.id ? debt.to : debt.from;
                    const otherUser = expenses.find(e => 
                      e.participants.some(p => p.userId === otherUserId)
                    )?.participants.find(p => p.userId === otherUserId)?.user;
                    
                    return (
                      <div key={index} className="flex items-center justify-between py-3 border-b border-gray-100">
                        <div className="flex items-center space-x-2">
                          <Avatar
                            src={otherUser?.avatarUrl}
                            name={otherUser?.name || 'Unknown'}
                            size="sm"
                          />
                          <div>
                            {debt.from === user.id ? (
                              <div className="flex items-center text-red-600 font-medium">
                                <span>You owe {otherUser?.name || 'Unknown'}</span>
                              </div>
                            ) : (
                              <div className="flex items-center text-green-600 font-medium">
                                <span>{otherUser?.name || 'Unknown'} owes you</span>
                              </div>
                            )}
                          </div>
                        </div>
                        <span className={`font-semibold ${
                          debt.from === user.id ? 'text-red-600' : 'text-green-600'
                        }`}>
                          {formatCurrency(debt.amount)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              relevantExpenses.length > 0 ? (
                <div className="p-6 text-center">
                  <div className="mb-2 text-3xl">✨</div>
                  <p className="text-gray-500">All settled up!</p>
                </div>
              ) : (
                <div className="p-6 text-center">
                  <p className="text-gray-500">No expenses found.</p>
                </div>
              )
            )}
          </>
        )}
      </div>
    </motion.div>
  );
};

export default BalanceSummary;
 