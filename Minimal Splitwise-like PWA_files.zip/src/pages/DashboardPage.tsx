import  React, { useEffect, useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';
import { 
  Plus, Settings, Users, User, Bell, Home,
  LogOut, ArrowLeft, Menu, X
} from 'lucide-react';
import { useAuthStore } from '../store/auth-store';
import { useExpenseStore } from '../store/expense-store';
import Button from '../components/ui/Button';
import ExpenseList from '../components/expenses/ExpenseList';
import ExpenseForm from '../components/expenses/ExpenseForm';
import GroupList from '../components/groups/GroupList';
import FriendsList from '../components/friends/FriendsList';
import NotificationList from '../components/notifications/NotificationList';
import BalanceSummary from '../components/balances/BalanceSummary';
import Modal from '../components/ui/Modal';
import Avatar from '../components/ui/Avatar';
import ProfilePage from './ProfilePage';

const DashboardPage: React.FC = () => {
  const { user, logout } = useAuthStore();
  const { syncPendingExpenses } = useExpenseStore();
  const [activePage, setActivePage] = useState<'home' | 'groups' | 'friends' | 'notifications' | 'profile'>('home');
  const [showAddExpenseModal, setShowAddExpenseModal] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState<string | undefined>(undefined);
  const [selectedFriendId, setSelectedFriendId] = useState<string | undefined>(undefined);
  const [ref, inView] = useInView({
    threshold: 0.1,
    triggerOnce: true
  });
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  useEffect(() => {
    // Sync pending expenses on connect
    const handleOnline = () => {
      syncPendingExpenses();
    };
    
    window.addEventListener('online', handleOnline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
    };
  }, [syncPendingExpenses]);
  
  const handleLogout = () => {
    logout();
  };
  
  const handleViewGroupExpenses = (groupId: string) => {
    setSelectedGroupId(groupId);
    setSelectedFriendId(undefined);
    setActivePage('home');
  };
  
  const handleViewFriendExpenses = (friendId: string) => {
    setSelectedFriendId(friendId);
    setSelectedGroupId(undefined);
    setActivePage('home');
  };
  
  const navigation = [
    { name: 'Home', icon: Home, page: 'home' },
    { name: 'Groups', icon: Users, page: 'groups' },
    { name: 'Friends', icon: User, page: 'friends' },
    { name: 'Notifications', icon: Bell, page: 'notifications' },
    { name: 'Profile', icon: Settings, page: 'profile' }
  ];
  
  const renderActivePage = () => {
    switch (activePage) {
      case 'home':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="pb-16"
          >
            <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {selectedGroupId ? 'Group Expenses' : 
                   selectedFriendId ? 'Expenses with Friend' : 
                   'Your Expenses'}
                </h1>
                {(selectedGroupId || selectedFriendId) && (
                  <button 
                    onClick={() => {
                      setSelectedGroupId(undefined);
                      setSelectedFriendId(undefined);
                    }}
                    className="text-sm text-primary-600 hover:text-primary-800 flex items-center"
                  >
                    <ArrowLeft size={14} className="mr-1" />
                    Back to all expenses
                  </button>
                )}
              </div>
              
              <Button
                onClick={() => setShowAddExpenseModal(true)}
                leftIcon={<Plus size={18} />}
              >
                Add Expense
              </Button>
            </div>
            
            <div ref={ref}>
              {inView && (
                <>
                  <BalanceSummary 
                    groupId={selectedGroupId} 
                    friendId={selectedFriendId} 
                  />
                  
                  <ExpenseList 
                    groupId={selectedGroupId}
                    friendId={selectedFriendId}
                  />
                </>
              )}
            </div>
          </motion.div>
        );
      case 'groups':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="pb-16"
          >
            <GroupList onViewGroupExpenses={handleViewGroupExpenses} />
          </motion.div>
        );
      case 'friends':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="pb-16"
          >
            <FriendsList onViewFriendExpenses={handleViewFriendExpenses} />
          </motion.div>
        );
      case 'notifications':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="pb-16"
          >
            <NotificationList />
          </motion.div>
        );
      case 'profile':
        return (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="pb-16"
          >
            <ProfilePage />
          </motion.div>
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top navbar */}
      <header className="bg-white border-b border-gray-200 z-10 sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <button 
                  className="lg:hidden p-2 mr-2 rounded-md text-gray-500"
                  onClick={() => setIsMobileMenuOpen(true)}
                >
                  <Menu size={24} />
                </button>
                <div className="flex items-center space-x-2">
                  <div className="bg-primary-100 p-1.5 rounded-lg">
                    <Users className="h-5 w-5 text-primary-600" />
                  </div>
                  <span className="text-xl font-semibold text-gray-900">SplitEase</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center">
              <button
                onClick={() => setActivePage('profile')}
                className="ml-3 flex rounded-full overflow-hidden focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                <Avatar 
                  src={user?.avatarUrl}
                  name={user?.name || 'User'}
                  size="sm"
                />
              </button>
            </div>
          </div>
        </div>
      </header>
      
      {/* Mobile menu */}
      <div className={`fixed inset-0 z-50 ${isMobileMenuOpen ? 'block' : 'hidden'} lg:hidden`}>
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75"></div>
        
        <div className="fixed inset-y-0 left-0 flex flex-col max-w-xs w-full bg-white shadow-xl">
          <div className="h-16 flex items-center justify-between px-4 border-b border-gray-200">
            <div className="flex items-center space-x-2">
              <div className="bg-primary-100 p-1.5 rounded-lg">
                <Users className="h-5 w-5 text-primary-600" />
              </div>
              <span className="text-lg font-semibold text-gray-900">SplitEase</span>
            </div>
            <button
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2 rounded-md text-gray-500"
            >
              <X size={24} />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto pt-2 pb-4">
            <nav className="mt-2 px-2 space-y-1">
              {navigation.map((item) => (
                <button
                  key={item.name}
                  onClick={() => {
                    setActivePage(item.page as any);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`flex items-center px-3 py-2 text-base font-medium rounded-md w-full ${
                    activePage === item.page
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <item.icon
                    size={20}
                    className={`mr-3 ${
                      activePage === item.page ? 'text-primary-500' : 'text-gray-500'
                    }`}
                  />
                  {item.name}
                </button>
              ))}
            </nav>
          </div>
          
          <div className="border-t border-gray-200 p-4">
            <button
              onClick={handleLogout}
              className="flex items-center px-3 py-2 text-base font-medium rounded-md text-red-600 hover:bg-red-50 w-full"
            >
              <LogOut size={20} className="mr-3 text-red-500" />
              Sign out
            </button>
          </div>
        </div>
      </div>
      
      {/* Main content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:flex">
        {/* Desktop sidebar */}
        <div className="hidden lg:block lg:w-64 lg:pr-8 flex-shrink-0">
          <nav className="sticky top-24 space-y-2">
            {navigation.map((item) => (
              <button
                key={item.name}
                onClick={() => setActivePage(item.page as any)}
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md w-full ${
                  activePage === item.page
                    ? 'bg-primary-50 text-primary-700'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <item.icon
                  size={18}
                  className={`mr-3 ${
                    activePage === item.page ? 'text-primary-500' : 'text-gray-500'
                  }`}
                />
                {item.name}
              </button>
            ))}
            
            <button
              onClick={handleLogout}
              className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-red-600 hover:bg-red-50 w-full mt-8"
            >
              <LogOut size={18} className="mr-3 text-red-500" />
              Sign out
            </button>
          </nav>
        </div>
        
        {/* Content area */}
        <div className="lg:flex-1">
          {renderActivePage()}
        </div>
      </main>
      
      {/* Mobile bottom nav */}
      <div className="lg:hidden fixed bottom-0 inset-x-0 bg-white border-t border-gray-200 z-10">
        <div className="grid grid-cols-5 h-16">
          {navigation.map((item) => (
            <button
              key={item.name}
              onClick={() => setActivePage(item.page as any)}
              className="flex flex-col items-center justify-center"
            >
              <item.icon
                size={20}
                className={`${
                  activePage === item.page ? 'text-primary-600' : 'text-gray-500'
                }`}
              />
              <span 
                className={`text-xs mt-1 ${
                  activePage === item.page ? 'text-primary-600 font-medium' : 'text-gray-500'
                }`}
              >
                {item.name}
              </span>
            </button>
          ))}
        </div>
      </div>
      
      {/* Add Expense Modal */}
      <Modal
        isOpen={showAddExpenseModal}
        onClose={() => setShowAddExpenseModal(false)}
        title="Add an Expense"
        size="md"
      >
        <ExpenseForm
          groupId={selectedGroupId}
          friendId={selectedFriendId}
          onSuccess={() => setShowAddExpenseModal(false)}
          onCancel={() => setShowAddExpenseModal(false)}
        />
      </Modal>
    </div>
  );
};

export default DashboardPage;
 