import  { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { Expense } from '../types';

interface ExpenseState {
  expenses: Expense[];
  pendingSync: Expense[];
  loading: boolean;
  error: string | null;
  fetchExpenses: () => Promise<void>;
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Expense>;
  updateExpense: (id: string, expense: Partial<Expense>) => Promise<void>;
  deleteExpense: (id: string) => Promise<void>;
  syncPendingExpenses: () => Promise<void>;
  exportExpensesCsv: (groupId?: string, userId?: string) => void;
}

export const useExpenseStore = create<ExpenseState>((set, get) => ({
  expenses: [],
  pendingSync: [],
  loading: false,
  error: null,

  fetchExpenses: async () => {
    set({ loading: true, error: null });
    
    try {
      // For demo purposes, we're simulating fetching expenses with a delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Check for stored expenses in localStorage
      const storedExpenses = localStorage.getItem('splitease-expenses');
      if (storedExpenses) {
        set({ expenses: JSON.parse(storedExpenses), loading: false });
        return;
      }
      
      // If no stored expenses, use initial demo data
      const initialExpenses: Expense[] = [
        {
          id: 'expense-1',
          description: 'Dinner at Restaurant',
          amount: 1250,
          category: 'Food & Drink',
          notes: 'Birthday celebration',
          payerId: 'user-demo',
          groupId: 'group-1',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          splitType: 'equal',
          participants: [
            {
              id: 'participant-1',
              userId: 'user-demo',
              shareAmount: 416.67,
              paidAmount: 1250,
              user: {
                id: 'user-demo',
                name: 'Demo User',
                email: 'demo@example.com'
              }
            },
            {
              id: 'participant-2',
              userId: 'user-1',
              shareAmount: 416.67,
              paidAmount: 0,
              user: {
                id: 'user-1',
                name: 'Alex Johnson',
                email: 'alex@example.com'
              }
            },
            {
              id: 'participant-3',
              userId: 'user-2',
              shareAmount: 416.67,
              paidAmount: 0,
              user: {
                id: 'user-2',
                name: 'Sam Wilson',
                email: 'sam@example.com'
              }
            }
          ]
        },
        {
          id: 'expense-2',
          description: 'Groceries',
          amount: 500,
          category: 'Groceries',
          payerId: 'user-1',
          createdAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
          updatedAt: new Date(Date.now() - 86400000).toISOString(),
          splitType: 'equal',
          participants: [
            {
              id: 'participant-4',
              userId: 'user-demo',
              shareAmount: 250,
              paidAmount: 0,
              user: {
                id: 'user-demo',
                name: 'Demo User',
                email: 'demo@example.com'
              }
            },
            {
              id: 'participant-5',
              userId: 'user-1',
              shareAmount: 250,
              paidAmount: 500,
              user: {
                id: 'user-1',
                name: 'Alex Johnson',
                email: 'alex@example.com'
              }
            }
          ]
        }
      ];
      
      // Save to localStorage
      localStorage.setItem('splitease-expenses', JSON.stringify(initialExpenses));
      
      set({ expenses: initialExpenses, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  addExpense: async (expenseData) => {
    set({ loading: true, error: null });
    
    try {
      const { expenses } = get();
      
      const newExpense: Expense = {
        id: uuidv4(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        ...expenseData
      };
      
      const updatedExpenses = [newExpense, ...expenses];
      
      // Check if online
      if (navigator.onLine) {
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Save to localStorage
        localStorage.setItem('splitease-expenses', JSON.stringify(updatedExpenses));
        
        set({ expenses: updatedExpenses, loading: false });
      } else {
        // Add to pending sync queue
        const { pendingSync } = get();
        const updatedPendingSync = [...pendingSync, newExpense];
        
        localStorage.setItem('splitease-pending-sync', JSON.stringify(updatedPendingSync));
        
        set({ 
          expenses: updatedExpenses, 
          pendingSync: updatedPendingSync,
          loading: false 
        });
      }
      
      return newExpense;
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  updateExpense: async (id, expenseData) => {
    set({ loading: true, error: null });
    
    try {
      const { expenses } = get();
      
      const expenseIndex = expenses.findIndex((e) => e.id === id);
      if (expenseIndex === -1) {
        throw new Error('Expense not found');
      }
      
      const updatedExpense = {
        ...expenses[expenseIndex],
        ...expenseData,
        updatedAt: new Date().toISOString()
      };
      
      const updatedExpenses = [...expenses];
      updatedExpenses[expenseIndex] = updatedExpense;
      
      // Check if online
      if (navigator.onLine) {
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Save to localStorage
        localStorage.setItem('splitease-expenses', JSON.stringify(updatedExpenses));
        
        set({ expenses: updatedExpenses, loading: false });
      } else {
        // Add to pending sync queue
        const { pendingSync } = get();
        const pendingIndex = pendingSync.findIndex((e) => e.id === id);
        
        let updatedPendingSync = [...pendingSync];
        if (pendingIndex !== -1) {
          updatedPendingSync[pendingIndex] = updatedExpense;
        } else {
          updatedPendingSync.push(updatedExpense);
        }
        
        localStorage.setItem('splitease-pending-sync', JSON.stringify(updatedPendingSync));
        
        set({ 
          expenses: updatedExpenses, 
          pendingSync: updatedPendingSync,
          loading: false 
        });
      }
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  deleteExpense: async (id) => {
    set({ loading: true, error: null });
    
    try {
      const { expenses } = get();
      
      const updatedExpenses = expenses.filter((e) => e.id !== id);
      
      // Check if online
      if (navigator.onLine) {
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Save to localStorage
        localStorage.setItem('splitease-expenses', JSON.stringify(updatedExpenses));
        
        set({ expenses: updatedExpenses, loading: false });
      } else {
        // Add to pending sync queue - for delete we'll add a special flag
        const { pendingSync } = get();
        const pendingIndex = pendingSync.findIndex((e) => e.id === id);
        
        let updatedPendingSync = [...pendingSync];
        if (pendingIndex !== -1) {
          // Remove from pending if it was there
          updatedPendingSync = updatedPendingSync.filter((e) => e.id !== id);
        } else {
          // Add delete marker
          updatedPendingSync.push({
            id,
            _deleted: true
          } as any);
        }
        
        localStorage.setItem('splitease-pending-sync', JSON.stringify(updatedPendingSync));
        
        set({ 
          expenses: updatedExpenses, 
          pendingSync: updatedPendingSync,
          loading: false 
        });
      }
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  syncPendingExpenses: async () => {
    const { pendingSync } = get();
    
    if (pendingSync.length === 0 || !navigator.onLine) {
      return;
    }
    
    set({ loading: true });
    
    try {
      // Simulate synchronization with delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In a real app, you would send the pendingSync items to the server
      // here we just update localStorage
      const { expenses } = get();
      
      // Process each pending item
      pendingSync.forEach(pendingItem => {
        if ((pendingItem as any)._deleted) {
          // No need to do anything as we've already removed it from expenses
        } else {
          const existingIndex = expenses.findIndex(e => e.id === pendingItem.id);
          if (existingIndex !== -1) {
            expenses[existingIndex] = pendingItem;
          } else {
            expenses.push(pendingItem);
          }
        }
      });
      
      // Update localStorage with synced data
      localStorage.setItem('splitease-expenses', JSON.stringify(expenses));
      localStorage.removeItem('splitease-pending-sync');
      
      set({ expenses, pendingSync: [], loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  exportExpensesCsv: (groupId, userId) => {
    const { expenses } = get();
    
    // Filter expenses if groupId or userId is provided
    let filteredExpenses = [...expenses];
    
    if (groupId) {
      filteredExpenses = filteredExpenses.filter(e => e.groupId === groupId);
    }
    
    if (userId) {
      filteredExpenses = filteredExpenses.filter(e => 
        e.participants.some(p => p.userId === userId)
      );
    }
    
    // Generate CSV content
    const headers = ['Date', 'Description', 'Category', 'Amount', 'Paid By', 'Group', 'Notes'];
    
    const csvRows = [
      headers.join(','),
      ...filteredExpenses.map(expense => {
        const date = new Date(expense.createdAt).toLocaleDateString();
        const description = `"${expense.description.replace(/"/g, '""')}"`;
        const category = `"${expense.category}"`;
        const amount = expense.amount.toFixed(2);
        const paidBy = `"${expense.payer?.name || 'Unknown'}"`;
        const group = expense.groupId ? `"${expense.group?.name || 'Unknown'}"` : '""';
        const notes = expense.notes ? `"${expense.notes.replace(/"/g, '""')}"` : '""';
        
        return [date, description, category, amount, paidBy, group, notes].join(',');
      })
    ];
    
    const csvContent = csvRows.join('\n');
    
    // Create a download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `expenses_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}));
 