import  React, { useEffect, useState } from 'react';
import { useAuthStore } from './store/auth-store';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';

function App() {
  const { user, initialized, initialize } = useAuthStore();
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Register service worker for PWA
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', async () => {
        try {
          const reg = await navigator.serviceWorker.register('/sw.js');
          console.log('Service worker registered!', reg);
          
          // Listen for messages from service worker
          navigator.serviceWorker.addEventListener('message', (event) => {
            if (event.data && event.data.type === 'SYNC_REQUESTED') {
              console.log('Sync requested by service worker');
              // Here you could call your sync function
            }
          });
        } catch (error) {
          console.log('Service worker registration failed:', error);
        }
      });
    }
    
    // Initialize auth
    const init = async () => {
      await initialize();
      setIsLoading(false);
    };
    
    init();
  }, [initialize]);

  if (isLoading || !initialized) {
    return (
      <div className="flex w-full h-screen items-center justify-center flex-col space-y-3 p-2">
        <span className="loader" />
        <div className="text-base font-semibold">
          Loading...
        </div>
      </div>
    );
  }

  return (
    <>
      {user ? <DashboardPage /> : <LoginPage />}
    </>
  );
}

export default App;
 