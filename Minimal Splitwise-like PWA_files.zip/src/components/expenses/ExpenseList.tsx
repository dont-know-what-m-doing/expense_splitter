import  React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, Filter, Plus } from 'lucide-react';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import ExpenseItem from './ExpenseItem';
import ExpenseForm from './ExpenseForm';
import { useExpenseStore } from '../../store/expense-store';
import { useAuthStore } from '../../store/auth-store';
import { Expense, EXPENSE_CATEGORIES } from '../../types';

interface ExpenseListProps {
  groupId?: string;
  friendId?: string;
}

const ExpenseList: React.FC<ExpenseListProps> = ({ groupId, friendId }) => {
  const { user } = useAuthStore();
  const { expenses, fetchExpenses, deleteExpense, loading } = useExpenseStore();
  
  const [filteredExpenses, setFilteredExpenses] = useState<Expense[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null);
  const [selectedTimeFrame, setSelectedTimeFrame] = useState<'all' | 'month' | 'week'>('all');
  
  useEffect(() => {
    fetchExpenses();
  }, [fetchExpenses]);
  
  useEffect(() => {
    if (expenses.length === 0) return;
    
    let filtered = [...expenses];
    
    // Filter by group if specified
    if (groupId) {
      filtered = filtered.filter(expense => expense.groupId === groupId);
    }
    
    // Filter by friend if specified
    if (friendId && user) {
      filtered = filtered.filter(expense => 
        expense.participants.some(p => p.userId === friendId) && 
        expense.participants.some(p => p.userId === user.id)
      );
    }
    
    // Filter by category if selected
    if (selectedCategory) {
      filtered = filtered.filter(expense => expense.category === selectedCategory);
    }
    
    // Filter by time frame
    if (selectedTimeFrame !== 'all') {
      const now = new Date();
      let startDate: Date;
      
      if (selectedTimeFrame === 'week') {
        // Start of the current week
        const day = now.getDay(); // 0-6, 0 is Sunday
        startDate = new Date(now);
        startDate.setDate(now.getDate() - day);
        startDate.setHours(0, 0, 0, 0);
      } else if (selectedTimeFrame === 'month') {
        // Start of the current month
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
      } else {
        startDate = new Date(0); // Beginning of time
      }
      
      filtered = filtered.filter(expense => 
        new Date(expense.createdAt) >= startDate
      );
    }
    
    // Sort by date, newest first
    filtered.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    setFilteredExpenses(filtered);
  }, [expenses, groupId, friendId, selectedCategory, selectedTimeFrame, user]);
  
  const handleEditExpense = (expense: Expense) => {
    setSelectedExpense(expense);
    setShowEditModal(true);
  };
  
  const handleDeleteExpense = async (id: string) => {
    await deleteExpense(id);
  };
  
  if (!user) return null;
  
  return (
    <div className="pb-16">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-2">
          <select
            className="text-sm bg-white border border-gray-300 rounded-lg py-1.5 px-2.5 focus:border-primary-500 focus:ring-primary-500"
            value={selectedTimeFrame}
            onChange={(e) => setSelectedTimeFrame(e.target.value as any)}
          >
            <option value="all">All time</option>
            <option value="month">This month</option>
            <option value="week">This week</option>
          </select>
          
          <select
            className="text-sm bg-white border border-gray-300 rounded-lg py-1.5 px-2.5 focus:border-primary-500 focus:ring-primary-500"
            value={selectedCategory || ''}
            onChange={(e) => setSelectedCategory(e.target.value || null)}
          >
            <option value="">All categories</option>
            {EXPENSE_CATEGORIES.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        
        <Button
          variant="outline"
          size="sm"
          leftIcon={<Filter size={16} />}
          className="hidden sm:flex"
        >
          More filters
        </Button>
      </div>
      
      {loading ? (
        <div className="flex justify-center py-10">
          <RefreshCw size={24} className="animate-spin text-primary-500" />
        </div>
      ) : filteredExpenses.length === 0 ? (
        <div className="text-center py-10 bg-gray-50 rounded-xl border border-gray-200">
          <div className="mb-4 text-gray-400">
            <CreditCard size={48} className="mx-auto opacity-30" />
          </div>
          <p className="text-gray-500 mb-6">No expenses found</p>
          <Button
            onClick={() => {
              setSelectedExpense(null);
              setShowEditModal(true);
            }}
            leftIcon={<Plus size={16} />}
            size="sm"
          >
            Add your first expense
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredExpenses.map(expense => (
            <ExpenseItem
              key={expense.id}
              expense={expense}
              currentUserId={user.id}
              onEdit={handleEditExpense}
              onDelete={handleDeleteExpense}
            />
          ))}
        </div>
      )}
      
      <Modal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        title={selectedExpense ? "Edit Expense" : "Add Expense"}
        size="lg"
      >
        <ExpenseForm
          expense={selectedExpense || undefined}
          groupId={groupId}
          friendId={friendId}
          onSuccess={() => setShowEditModal(false)}
          onCancel={() => setShowEditModal(false)}
        />
      </Modal>
    </div>
  );
};

export default ExpenseList;
 