import  React from 'react';
import { motion } from 'framer-motion';
import { Edit, Trash, Users, Download, ArrowRight } from 'lucide-react';
import { Group } from '../../types';
import Button from '../ui/Button';
import Avatar from '../ui/Avatar';

interface GroupItemProps {
  group: Group;
  onEdit: (group: Group) => void;
  onDelete: (id: string) => void;
  onViewExpenses: (id: string) => void;
  onExport: (id: string) => void;
  onManageMembers: (group: Group) => void;
}

const GroupItem: React.FC<GroupItemProps> = ({
  group,
  onEdit,
  onDelete,
  onViewExpenses,
  onExport,
  onManageMembers
}) => {
  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this group? All associated expenses will be deleted as well.')) {
      onDelete(group.id);
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      className="bg-white rounded-xl shadow-soft p-4 mb-4"
    >
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="font-medium text-gray-900 text-lg">{group.name}</h3>
          <p className="text-sm text-gray-500">
            {group.members?.length || 0} members
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onViewExpenses(group.id)}
          className="text-primary-600"
          rightIcon={<ArrowRight size={16} />}
        >
          View
        </Button>
      </div>
      
      {group.members && group.members.length > 0 && (
        <div className="flex -space-x-2 mb-4">
          {group.members.slice(0, 5).map((member) => (
            <Avatar
              key={member.id}
              src={member.avatarUrl}
              name={member.name}
              size="sm"
              borderColor="white"
              className="ring-2 ring-white"
            />
          ))}
          {group.members.length > 5 && (
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-200 text-xs font-medium text-gray-600 ring-2 ring-white">
              +{group.members.length - 5}
            </div>
          )}
        </div>
      )}
      
      <div className="flex flex-wrap gap-2">
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onManageMembers(group)}
          leftIcon={<Users size={14} />}
        >
          Members
        </Button>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onExport(group.id)}
          leftIcon={<Download size={14} />}
        >
          Export
        </Button>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={() => onEdit(group)}
          leftIcon={<Edit size={14} />}
          className="text-gray-600"
        >
          Edit
        </Button>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={handleDelete}
          leftIcon={<Trash size={14} />}
          className="text-red-600"
        >
          Delete
        </Button>
      </div>
    </motion.div>
  );
};

export default GroupItem;
 