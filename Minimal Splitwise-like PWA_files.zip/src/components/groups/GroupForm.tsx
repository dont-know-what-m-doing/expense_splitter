import  React, { useState } from 'react';
import { Users, Plus } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { useGroupStore } from '../../store/group-store';
import { useAuthStore } from '../../store/auth-store';

interface GroupFormProps {
  group?: any;
  onSuccess?: () => void;
  onCancel?: () => void;
}

const GroupForm: React.FC<GroupFormProps> = ({
  group,
  onSuccess,
  onCancel
}) => {
  const { user } = useAuthStore();
  const { createGroup, updateGroup, loading, error } = useGroupStore();
  
  const [name, setName] = useState(group?.name || '');
  const [formError, setFormError] = useState('');
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    
    if (!name.trim()) {
      setFormError('Please enter a group name');
      return;
    }
    
    try {
      if (group) {
        await updateGroup(group.id, name);
      } else {
        if (!user?.id) {
          setFormError('You must be logged in to create a group');
          return;
        }
        await createGroup(name, user.id);
      }
      
      if (onSuccess) onSuccess();
    } catch (error: any) {
      setFormError(error.message);
    }
  };
  
  return (
    <form className="space-y-4" onSubmit={handleSubmit}>
      <Input
        label="Group Name"
        type="text"
        placeholder="Enter group name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        icon={<Users size={18} className="text-gray-400" />}
        required
      />
      
      {(formError || error) && (
        <div className="p-3 text-sm text-red-600 bg-red-50 rounded-lg border border-red-200">
          {formError || error}
        </div>
      )}
      
      <div className="flex space-x-2 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="flex-1"
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={loading}
          className="flex-1"
          isLoading={loading}
          leftIcon={group ? undefined : <Plus size={16} />}
        >
          {group ? 'Update' : 'Create'} Group
        </Button>
      </div>
    </form>
  );
};

export default GroupForm;
 