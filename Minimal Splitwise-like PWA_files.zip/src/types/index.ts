export  const EXPENSE_CATEGORIES = [
  'Food & Drink',
  'Groceries',
  'Transportation',
  'Housing',
  'Utilities',
  'Entertainment',
  'Travel',
  'Shopping',
  'Health',
  'Education',
  'Gifts',
  'Other'
];

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
}

export interface Group {
  id: string;
  name: string;
  description?: string;
  members: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface ExpenseParticipant {
  id?: string;
  userId: string;
  shareAmount: number;
  paidAmount: number;
  sharePercentage?: number;
  shares?: number;
  user?: User;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  notes?: string;
  payerId: string;
  groupId?: string | null;
  createdAt: string;
  updatedAt: string;
  payer?: User;
  group?: Group;
  splitType: 'equal' | 'custom' | 'percentage' | 'shares';
  multiplePayersMode?: 'equal' | 'custom';
  participants: ExpenseParticipant[];
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  read: boolean;
  createdAt: string;
  expenseId?: string;
  groupId?: string;
}
 