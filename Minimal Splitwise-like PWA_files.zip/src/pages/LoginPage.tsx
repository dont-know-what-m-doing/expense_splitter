import  React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Info } from 'lucide-react';
import AuthForm from '../components/auth/AuthForm';

const LoginPage: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [showCredentials, setShowCredentials] = useState(false);
  const pageRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // Show credentials hint after a short delay
    const timer = setTimeout(() => {
      setShowCredentials(true);
    }, 800);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div ref={pageRef} className="min-h-screen w-full overflow-y-auto bg-gradient-primary">
      <div className="absolute inset-0 image-overlay">
        <img 
          src="https://images.unsplash.com/photo-1487260211189-670c54da558d?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxtaW5pbWFsJTIwbW9kZXJuJTIwbW9iaWxlJTIwd2FsbGV0JTIwbW9uZXklMjBhcHAlMjB1aXxlbnwwfHx8fDE3NDc3MzYwNTN8MA&ixlib=rb-4.1.0&fit=fillmax&h=600&w=800" 
          alt="Minimal background" 
          className="w-full h-full object-cover opacity-30"
        />
      </div>
      
      {/* Top Nav Bar */}
      <header className="relative glass border-b border-white/20 py-3 px-4 z-10">
        <div className="flex items-center justify-between max-w-xl mx-auto">
          <div className="flex items-center space-x-2">
            <div className="bg-white p-1.5 rounded-lg shadow-sleek">
              <ShoppingBag className="h-5 w-5 text-primary-600" />
            </div>
            <h1 className="text-xl font-semibold text-white text-shadow">SplitEase</h1>
          </div>
        </div>
      </header>
      
      <div className="relative flex-1 flex flex-col justify-center px-4 py-10 sm:px-6 lg:flex-none lg:px-20 z-10">
        <div className="mx-auto w-full max-w-md">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="bg-white/90 backdrop-blur-md shadow-sleek rounded-xl p-6 border border-white/40"
          >
            <div className="text-center mb-6">
              <div className="mx-auto h-14 w-14 rounded-full bg-primary-100 flex items-center justify-center mb-3 shadow-md">
                <ShoppingBag className="h-7 w-7 text-primary-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">
                {isLogin ? 'Welcome to SplitEase!' : 'Create an account'}
              </h2>
              <p className="mt-1 text-sm text-gray-500">
                {isLogin ? 'Sign in to start splitting expenses' : 'Sign up to get started'}
              </p>
            </div>
            
            {showCredentials && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                transition={{ duration: 0.3 }}
                className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-100 text-sm"
              >
                <div className="flex items-start space-x-2">
                  <Info size={18} className="text-blue-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium text-blue-700 mb-1">Demo Credentials</p>
                    <p className="text-blue-600">Email: <span className="font-mono">demo@example.com</span></p>
                    <p className="text-blue-600">Password: <span className="font-mono">password</span></p>
                    <p className="text-blue-600">Admin Code: <span className="font-mono">123456</span></p>
                  </div>
                </div>
              </motion.div>
            )}
            
            <div className="flex bg-gray-100 p-1 rounded-lg mb-6">
              <button
                className={`flex-1 px-4 py-2.5 text-sm font-medium rounded-md transition-all ${
                  isLogin
                    ? 'bg-white shadow-md text-gray-900'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setIsLogin(true)}
              >
                Sign In
              </button>
              <button
                className={`flex-1 px-4 py-2.5 text-sm font-medium rounded-md transition-all ${
                  !isLogin
                    ? 'bg-white shadow-md text-gray-900'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setIsLogin(false)}
              >
                Sign Up
              </button>
            </div>
            
            <AuthForm
              isRegister={!isLogin}
              onToggleMode={() => setIsLogin(!isLogin)}
            />
          </motion.div>
          
          <div className="mt-4 text-center">
            <p className="text-xs text-white/80">
              By continuing, you agree to SplitEase's Terms of Service and Privacy Policy.
            </p>
          </div>
        </div>
      </div>
      
      <div className="relative py-6 px-4 sm:px-6 text-center z-10">
        <div className="text-xs text-white/80">
          <p>&copy; {new Date().getFullYear()} SplitEase. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
 