import  React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Lock, Eye, EyeOff, User, Key, RefreshCw } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { useAuthStore } from '../../store/auth-store';

interface AuthFormProps {
  isRegister?: boolean;
  onToggleMode?: () => void;
}

const AuthForm: React.FC<AuthFormProps> = ({ isRegister = false, onToggleMode }) => {
  const { login, register, loading, error } = useAuthStore();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [adminCode, setAdminCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [formError, setFormError] = useState('');
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Reset form error
    setFormError('');
    
    // Validate form
    if (!email || !password) {
      setFormError('Please fill in all required fields');
      return;
    }
    
    if (isRegister && !name) {
      setFormError('Please enter your name');
      return;
    }
    
    if (!adminCode) {
      setFormError('Admin code is required to access the app');
      return;
    }
    
    try {
      if (isRegister) {
        await register(email, password, adminCode, name);
      } else {
        await login(email, password, adminCode);
      }
    } catch (error: any) {
      setFormError(error.message || 'Authentication failed');
    }
  };
  
  return (
    <motion.form
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
      onSubmit={handleSubmit}
    >
      {isRegister && (
        <Input
          label="Name"
          type="text"
          placeholder="Enter your full name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          icon={<User size={18} className="text-gray-400" />}
          required
        />
      )}
      
      <Input
        label="Email address"
        type="email"
        placeholder="Enter your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        icon={<Mail size={18} className="text-gray-400" />}
        required
      />
      
      <div className="relative">
        <Input
          label="Password"
          type={showPassword ? 'text' : 'password'}
          placeholder="Enter your password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          icon={<Lock size={18} className="text-gray-400" />}
          required
        />
        <button
          type="button"
          className="absolute right-3 top-[34px] text-gray-400 hover:text-gray-600"
          onClick={() => setShowPassword(!showPassword)}
        >
          {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
        </button>
      </div>
      
      <Input
        label="Admin Code"
        type="password"
        placeholder="Enter admin access code"
        value={adminCode}
        onChange={(e) => setAdminCode(e.target.value)}
        icon={<Key size={18} className="text-gray-400" />}
        required
      />
      
      {(error || formError) && (
        <div className="p-3 rounded-lg bg-red-50 text-red-600 text-sm border border-red-200">
          {error || formError}
        </div>
      )}
      
      <div className="pt-2">
        <Button
          type="submit"
          fullWidth
          disabled={loading}
          className="bg-gradient-primary hover:opacity-90 shadow-md"
        >
          {loading ? (
            <RefreshCw size={18} className="animate-spin mr-2" />
          ) : null}
          {isRegister ? 'Create Account' : 'Sign In'}
        </Button>
      </div>
      
      <div className="text-center">
        <button
          type="button"
          onClick={onToggleMode}
          className="text-sm text-primary-600 hover:text-primary-800"
        >
          {isRegister
            ? 'Already have an account? Sign in'
            : "Don't have an account? Sign up"}
        </button>
      </div>
    </motion.form>
  );
};

export default AuthForm;
 