import  { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { Group, User } from '../types';

interface GroupState {
  groups: Group[];
  loading: boolean;
  error: string | null;
  fetchGroups: () => Promise<void>;
  createGroup: (name: string, createdBy: string) => Promise<Group>;
  updateGroup: (id: string, name: string) => Promise<void>;
  deleteGroup: (id: string) => Promise<void>;
  addMemberToGroup: (groupId: string, userId: string) => Promise<void>;
  removeMemberFromGroup: (groupId: string, userId: string) => Promise<void>;
  fetchGroupMembers: (groupId: string) => Promise<User[]>;
}

export const useGroupStore = create<GroupState>((set, get) => ({
  groups: [],
  loading: false,
  error: null,

  fetchGroups: async () => {
    set({ loading: true, error: null });
    
    try {
      // For demo purposes, we're simulating fetching groups with a delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Check for stored groups in localStorage
      const storedGroups = localStorage.getItem('splitease-groups');
      if (storedGroups) {
        set({ groups: JSON.parse(storedGroups), loading: false });
        return;
      }
      
      // If no stored groups, use initial demo data
      const initialGroups: Group[] = [
        {
          id: 'group-1',
          name: 'Weekend Trip',
          description: 'Beach vacation expenses',
          members: ['user-demo', 'user-1', 'user-2'],
          createdBy: 'user-demo',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: 'group-2',
          name: 'Roommates',
          description: 'Apartment expenses',
          members: ['user-demo', 'user-2'],
          createdBy: 'user-2',
          createdAt: new Date(Date.now() - 86400000).toISOString(),
          updatedAt: new Date(Date.now() - 86400000).toISOString()
        }
      ];
      
      // Save to localStorage
      localStorage.setItem('splitease-groups', JSON.stringify(initialGroups));
      
      set({ groups: initialGroups, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
    }
  },

  createGroup: async (name, createdBy) => {
    set({ loading: true, error: null });
    
    try {
      const newGroup: Group = {
        id: uuidv4(),
        name,
        members: [createdBy],
        createdBy,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const { groups } = get();
      const updatedGroups = [...groups, newGroup];
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Save to localStorage
      localStorage.setItem('splitease-groups', JSON.stringify(updatedGroups));
      
      set({ groups: updatedGroups, loading: false });
      
      return newGroup;
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  updateGroup: async (id, name) => {
    set({ loading: true, error: null });
    
    try {
      const { groups } = get();
      
      const groupIndex = groups.findIndex((g) => g.id === id);
      if (groupIndex === -1) {
        throw new Error('Group not found');
      }
      
      const updatedGroup = {
        ...groups[groupIndex],
        name,
        updatedAt: new Date().toISOString()
      };
      
      const updatedGroups = [...groups];
      updatedGroups[groupIndex] = updatedGroup;
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Save to localStorage
      localStorage.setItem('splitease-groups', JSON.stringify(updatedGroups));
      
      set({ groups: updatedGroups, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  deleteGroup: async (id) => {
    set({ loading: true, error: null });
    
    try {
      const { groups } = get();
      
      const updatedGroups = groups.filter((g) => g.id !== id);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Save to localStorage
      localStorage.setItem('splitease-groups', JSON.stringify(updatedGroups));
      
      set({ groups: updatedGroups, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  addMemberToGroup: async (groupId, userId) => {
    set({ loading: true, error: null });
    
    try {
      const { groups } = get();
      
      const groupIndex = groups.findIndex((g) => g.id === groupId);
      if (groupIndex === -1) {
        throw new Error('Group not found');
      }
      
      const group = groups[groupIndex];
      
      if (group.members.includes(userId)) {
        throw new Error('User is already a member of this group');
      }
      
      const updatedGroup = {
        ...group,
        members: [...group.members, userId],
        updatedAt: new Date().toISOString()
      };
      
      const updatedGroups = [...groups];
      updatedGroups[groupIndex] = updatedGroup;
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Save to localStorage
      localStorage.setItem('splitease-groups', JSON.stringify(updatedGroups));
      
      set({ groups: updatedGroups, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  removeMemberFromGroup: async (groupId, userId) => {
    set({ loading: true, error: null });
    
    try {
      const { groups } = get();
      
      const groupIndex = groups.findIndex((g) => g.id === groupId);
      if (groupIndex === -1) {
        throw new Error('Group not found');
      }
      
      const group = groups[groupIndex];
      
      if (!group.members.includes(userId)) {
        throw new Error('User is not a member of this group');
      }
      
      const updatedGroup = {
        ...group,
        members: group.members.filter((id) => id !== userId),
        updatedAt: new Date().toISOString()
      };
      
      const updatedGroups = [...groups];
      updatedGroups[groupIndex] = updatedGroup;
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Save to localStorage
      localStorage.setItem('splitease-groups', JSON.stringify(updatedGroups));
      
      set({ groups: updatedGroups, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  fetchGroupMembers: async (groupId) => {
    try {
      const { groups } = get();
      
      const group = groups.find((g) => g.id === groupId);
      if (!group) {
        throw new Error('Group not found');
      }
      
      // For demo purposes, we'll return mock user data for the group members
      const mockUsers: User[] = [
        {
          id: 'user-demo',
          name: 'Demo User',
          email: 'demo@example.com'
        },
        {
          id: 'user-1',
          name: 'Alex Johnson',
          email: 'alex@example.com'
        },
        {
          id: 'user-2',
          name: 'Sam Wilson',
          email: 'sam@example.com'
        },
        {
          id: 'user-3',
          name: 'Jordan Lee',
          email: 'jordan@example.com'
        }
      ];
      
      const groupMembers = mockUsers.filter((user) => group.members.includes(user.id));
      
      return groupMembers;
    } catch (error: any) {
      set({ error: error.message });
      throw error;
    }
  }
}));
 