import  React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { v4 as uuidv4 } from 'uuid';
import { 
  CreditCard, Calendar, Tag, Users, FileText, Plus, X, User, 
  Check, UserPlus, ArrowLeft, ArrowRight, Percent, Share2, 
  DollarSign, SplitSquareHorizontal
} from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Avatar from '../ui/Avatar';
import { useAuthStore } from '../../store/auth-store';
import { useGroupStore } from '../../store/group-store';
import { useExpenseStore } from '../../store/expense-store';
import { calculateShareAmount, getCategoryIcon } from '../../lib/utils';
import { User as UserType, Group, Expense, EXPENSE_CATEGORIES } from '../../types';

interface ExpenseFormProps {
  expense?: Expense;
  groupId?: string;
  friendId?: string;
  onSuccess?: () => void;
  onCancel?: () => void;
}

const ExpenseForm: React.FC<ExpenseFormProps> = ({
  expense,
  groupId,
  friendId,
  onSuccess,
  onCancel
}) => {
  const { user } = useAuthStore();
  const { groups, fetchGroups, fetchGroupMembers } = useGroupStore();
  const { addExpense, updateExpense, loading } = useExpenseStore();
  
  const [amount, setAmount] = useState(expense?.amount?.toString() || '');
  const [description, setDescription] = useState(expense?.description || '');
  const [category, setCategory] = useState(expense?.category || EXPENSE_CATEGORIES[0]);
  const [notes, setNotes] = useState(expense?.notes || '');
  const [selectedGroupId, setSelectedGroupId] = useState(expense?.groupId || groupId || '');
  const [payerIds, setPayerIds] = useState<string[]>(expense?.payerId ? [expense.payerId] : user?.id ? [user.id] : []);
  const [participants, setParticipants] = useState<Array<{
    id?: string;
    userId: string;
    name: string;
    avatarUrl?: string;
    shareAmount: number;
    paidAmount: number;
    sharePercentage?: number;
    shares?: number;
  }>>([]);
  const [groupMembers, setGroupMembers] = useState<UserType[]>([]);
  const [splitType, setSplitType] = useState<'equal' | 'custom' | 'shares' | 'percentage'>(expense?.splitType || 'equal');
  const [multiplePayersMode, setMultiplePayersMode] = useState<'equal' | 'custom'>(expense?.multiplePayersMode || 'equal');
  const [error, setError] = useState('');
  const [step, setStep] = useState(1);
  const [totalShares, setTotalShares] = useState(0);
  
  // State for 1:1 expense
  const [selectedFriendId, setSelectedFriendId] = useState<string>(friendId || '');
  const [friendSearch, setFriendSearch] = useState('');
  const [searchResults, setSearchResults] = useState<UserType[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [expenseType, setExpenseType] = useState<'group' | 'personal'>(selectedGroupId ? 'group' : 'personal');
  const [inviteEmail, setInviteEmail] = useState('');
  const [invitePhone, setInvitePhone] = useState('');
  const [showInviteForm, setShowInviteForm] = useState(false);
  
  useEffect(() => {
    fetchGroups();
    
    // If friendId is provided, we need to fetch the friend's details
    if (friendId) {
      setExpenseType('personal');
      setSelectedFriendId(friendId);
      
      // Mock fetching friend details
      setTimeout(() => {
        const mockFriend = {
          id: friendId,
          name: 'Sam Wilson',
          email: 'sam@example.com'
        };
        
        setSearchResults([mockFriend]);
      }, 300);
    }
  }, [fetchGroups, friendId]);
  
  useEffect(() => {
    if (selectedGroupId) {
      setExpenseType('group');
      
      // Get members for the selected group
      const loadGroupMembers = async () => {
        const members = await fetchGroupMembers(selectedGroupId);
        setGroupMembers(members);
        
        // Set initial participants based on group members
        const initialParticipants = members.map(member => {
          const existingParticipant = expense?.participants?.find((p) => p.userId === member.id);
          
          return {
            id: existingParticipant?.id,
            userId: member.id,
            name: member.name,
            avatarUrl: member.avatarUrl,
            shareAmount: existingParticipant?.shareAmount || 0,
            paidAmount: existingParticipant?.paidAmount || 0,
            sharePercentage: existingParticipant?.sharePercentage || 0,
            shares: existingParticipant?.shares || 1
          };
        });
        
        setParticipants(initialParticipants);
      };
      
      loadGroupMembers();
    } else if (selectedFriendId && user) {
      setExpenseType('personal');
      
      // Set up participants for 1:1 expense
      const friend = searchResults.find(r => r.id === selectedFriendId);
      if (friend) {
        setParticipants([
          {
            userId: user.id,
            name: user.name,
            avatarUrl: user.avatarUrl,
            shareAmount: 0,
            paidAmount: 0,
            sharePercentage: 50,
            shares: 1
          },
          {
            userId: friend.id,
            name: friend.name,
            avatarUrl: friend.avatarUrl,
            shareAmount: 0,
            paidAmount: 0,
            sharePercentage: 50,
            shares: 1
          }
        ]);
      }
    } else if (user) {
      // If no group or friend, just include the current user
      setParticipants([{
        userId: user.id,
        name: user.name,
        avatarUrl: user.avatarUrl,
        shareAmount: 0,
        paidAmount: 0,
        sharePercentage: 100,
        shares: 1
      }]);
    }
  }, [selectedGroupId, selectedFriendId, expense, user, fetchGroupMembers, searchResults]);
  
  // Update share amounts when amount or split type changes
  useEffect(() => {
    if (amount && participants.length > 0) {
      const numericAmount = parseFloat(amount) || 0;
      
      let updatedParticipants = [...participants];
      
      // Calculate paid amounts based on payers
      const payerCount = payerIds.length;
      if (payerCount > 0) {
        if (multiplePayersMode === 'equal' && payerCount > 1) {
          const amountPerPayer = numericAmount / payerCount;
          updatedParticipants = updatedParticipants.map(p => ({
            ...p,
            paidAmount: payerIds.includes(p.userId) ? amountPerPayer : 0
          }));
        } else {
          // Either single payer or custom mode
          if (updatedParticipants.every(p => !payerIds.includes(p.userId) || p.paidAmount === 0)) {
            // Initial setting of paid amount for first payer
            if (payerIds.length === 1) {
              updatedParticipants = updatedParticipants.map(p => ({
                ...p,
                paidAmount: p.userId === payerIds[0] ? numericAmount : 0
              }));
            }
          }
        }
      }
      
      // Calculate share amounts based on split type
      if (splitType === 'equal') {
        const perPersonAmount = calculateShareAmount(numericAmount, participants.length);
        
        updatedParticipants = updatedParticipants.map(p => ({
          ...p,
          shareAmount: perPersonAmount,
          sharePercentage: 100 / participants.length
        }));
      } else if (splitType === 'percentage') {
        // Update share amounts based on percentages
        updatedParticipants = updatedParticipants.map(p => ({
          ...p,
          shareAmount: ((p.sharePercentage || 0) / 100) * numericAmount
        }));
      } else if (splitType === 'shares') {
        const totalShares = updatedParticipants.reduce((sum, p) => sum + (p.shares || 1), 0);
        setTotalShares(totalShares);
        
        if (totalShares > 0) {
          updatedParticipants = updatedParticipants.map(p => ({
            ...p,
            shareAmount: ((p.shares || 1) / totalShares) * numericAmount,
            sharePercentage: ((p.shares || 1) / totalShares) * 100
          }));
        }
      }
      
      setParticipants(updatedParticipants);
    }
  }, [amount, splitType, payerIds, multiplePayersMode]);
  
  // Helper to search for users by email
  const handleSearchFriend = async (search: string) => {
    setFriendSearch(search);
    
    if (search.length < 3) {
      setSearchResults([]);
      return;
    }
    
    setIsSearching(true);
    
    // Mock search results for development
    setTimeout(() => {
      const mockResults = [
        { id: 'user-1', name: 'Alex Johnson', email: 'alex@example.com' },
        { id: 'user-2', name: 'Sam Wilson', email: 'sam@example.com' },
        { id: 'user-3', name: 'Jordan Lee', email: 'jordan@example.com' }
      ].filter(u => 
        u.name.toLowerCase().includes(search.toLowerCase()) || 
        u.email.toLowerCase().includes(search.toLowerCase())
      );
      
      setSearchResults(mockResults);
      setIsSearching(false);
    }, 500);
  };
  
  const handleInviteFriend = async () => {
    if (!inviteEmail && !invitePhone) {
      setError('Please enter an email or phone number');
      return;
    }
    
    if (inviteEmail && !inviteEmail.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }
    
    // Mock invitation process
    setError('');
    // In a real app, this would create an invitation in the database
    
    alert(`Invitation sent to ${inviteEmail || invitePhone}`);
    setInviteEmail('');
    setInvitePhone('');
    setShowInviteForm(false);
  };
  
  const handleAddPayer = (userId: string) => {
    if (payerIds.includes(userId)) {
      // Remove from payers if already selected
      setPayerIds(payerIds.filter(id => id !== userId));
    } else {
      // Add to payers
      setPayerIds([...payerIds, userId]);
    }
  };
  
  const validateStep1 = () => {
    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      setError('Please enter a valid amount');
      return false;
    }
    
    if (!description) {
      setError('Please enter a description');
      return false;
    }
    
    if (expenseType === 'personal' && !selectedFriendId && !selectedGroupId) {
      setError('Please select a friend or group');
      return false;
    }
    
    return true;
  };
  
  const validateStep2 = () => {
    // Validate participants shares sum to total
    const totalAmount = parseFloat(amount) || 0;
    const totalShares = participants.reduce((sum, p) => sum + p.shareAmount, 0);
    
    // Allow a small rounding error (0.01)
    if (Math.abs(totalShares - totalAmount) > 0.01) {
      setError(`The sum of shares (${totalShares.toFixed(2)}) must equal the total amount (${totalAmount.toFixed(2)})`);
      return false;
    }
    
    // Check if there's at least one payer
    if (payerIds.length === 0) {
      setError('Please select at least one person who paid');
      return false;
    }
    
    // If there are multiple payers, validate total paid amount
    if (payerIds.length > 1) {
      const totalPaid = participants.reduce((sum, p) => sum + p.paidAmount, 0);
      if (Math.abs(totalPaid - totalAmount) > 0.01) {
        setError(`The total paid amount (${totalPaid.toFixed(2)}) must equal the total expense amount (${totalAmount.toFixed(2)})`);
        return false;
      }
    }
    
    return true;
  };
  
  const handleNext = () => {
    setError('');
    if (validateStep1()) {
      setStep(2);
    }
  };
  
  const handleBack = () => {
    setStep(1);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!validateStep2()) {
      return;
    }
    
    try {
      const expenseData = {
        amount: parseFloat(amount) || 0,
        description,
        payerId: payerIds[0], // For compatibility with existing logic
        groupId: selectedGroupId || null,
        category,
        notes,
        splitType,
        multiplePayersMode: payerIds.length > 1 ? multiplePayersMode : undefined,
        participants: participants.map(p => ({
          id: p.id || uuidv4(),
          userId: p.userId,
          shareAmount: p.shareAmount,
          paidAmount: p.paidAmount,
          sharePercentage: p.sharePercentage,
          shares: p.shares
        }))
      };
      
      if (expense?.id) {
        await updateExpense(expense.id, expenseData);
      } else {
        await addExpense(expenseData);
      }
      
      if (onSuccess) onSuccess();
    } catch (error: any) {
      setError(error.message);
    }
  };
  
  const handleShareChange = (userId: string, value: number, field: 'shareAmount' | 'paidAmount' | 'sharePercentage' | 'shares') => {
    setParticipants(participants.map(p => {
      if (p.userId === userId) {
        return { ...p, [field]: value };
      }
      return p;
    }));
  };
  
  const handlePercentageChange = (userId: string, percentage: number) => {
    const numericAmount = parseFloat(amount) || 0;
    
    // Update this participant
    const updatedParticipants = participants.map(p => {
      if (p.userId === userId) {
        return {
          ...p,
          sharePercentage: percentage,
          shareAmount: (percentage / 100) * numericAmount
        };
      }
      return p;
    });
    
    setParticipants(updatedParticipants);
  };
  
  const handleSharesChange = (userId: string, shares: number) => {
    const updatedParticipants = participants.map(p => {
      if (p.userId === userId) {
        return { ...p, shares };
      }
      return p;
    });
    
    const newTotalShares = updatedParticipants.reduce((sum, p) => sum + (p.shares || 1), 0);
    setTotalShares(newTotalShares);
    
    // Recalculate percentages and amounts based on new shares
    const numericAmount = parseFloat(amount) || 0;
    const finalParticipants = updatedParticipants.map(p => ({
      ...p,
      sharePercentage: ((p.shares || 1) / newTotalShares) * 100,
      shareAmount: ((p.shares || 1) / newTotalShares) * numericAmount
    }));
    
    setParticipants(finalParticipants);
  };
  
  const handlePaidAmountChange = (userId: string, paidAmount: number) => {
    setParticipants(participants.map(p => {
      if (p.userId === userId) {
        return { ...p, paidAmount };
      }
      return p;
    }));
  };
  
  const renderSplitTypeOptions = () => (
    <div className="grid grid-cols-2 gap-2 mt-2">
      <button
        type="button"
        onClick={() => setSplitType('equal')}
        className={`flex items-center justify-center p-2 rounded-lg border ${
          splitType === 'equal' 
            ? 'bg-primary-50 border-primary-300 text-primary-700' 
            : 'border-gray-300 hover:bg-gray-50'
        }`}
      >
        <SplitSquareHorizontal size={16} className="mr-2" />
        <span className="text-sm">Equal</span>
      </button>
      <button
        type="button"
        onClick={() => setSplitType('custom')}
        className={`flex items-center justify-center p-2 rounded-lg border ${
          splitType === 'custom' 
            ? 'bg-primary-50 border-primary-300 text-primary-700' 
            : 'border-gray-300 hover:bg-gray-50'
        }`}
      >
        <DollarSign size={16} className="mr-2" />
        <span className="text-sm">Custom</span>
      </button>
      <button
        type="button"
        onClick={() => setSplitType('percentage')}
        className={`flex items-center justify-center p-2 rounded-lg border ${
          splitType === 'percentage' 
            ? 'bg-primary-50 border-primary-300 text-primary-700' 
            : 'border-gray-300 hover:bg-gray-50'
        }`}
      >
        <Percent size={16} className="mr-2" />
        <span className="text-sm">Percentage</span>
      </button>
      <button
        type="button"
        onClick={() => setSplitType('shares')}
        className={`flex items-center justify-center p-2 rounded-lg border ${
          splitType === 'shares' 
            ? 'bg-primary-50 border-primary-300 text-primary-700' 
            : 'border-gray-300 hover:bg-gray-50'
        }`}
      >
        <Share2 size={16} className="mr-2" />
        <span className="text-sm">Shares</span>
      </button>
    </div>
  );
  
  const renderPayerSelector = () => (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <label className="block text-sm font-medium text-gray-700">Paid by</label>
        {payerIds.length > 1 && (
          <div className="flex space-x-2">
            <button
              type="button"
              onClick={() => setMultiplePayersMode('equal')}
              className={`text-xs px-2 py-1 rounded ${
                multiplePayersMode === 'equal' 
                  ? 'bg-primary-100 text-primary-700' 
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              Equal
            </button>
            <button
              type="button"
              onClick={() => setMultiplePayersMode('custom')}
              className={`text-xs px-2 py-1 rounded ${
                multiplePayersMode === 'custom' 
                  ? 'bg-primary-100 text-primary-700' 
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              Custom
            </button>
          </div>
        )}
      </div>
      
      <div className="space-y-2 max-h-28 overflow-y-auto">
        {participants.map(participant => (
          <div 
            key={participant.userId}
            className={`flex items-center justify-between p-2 rounded-lg border ${
              payerIds.includes(participant.userId)
                ? 'bg-green-50 border-green-200'
                : 'border-gray-200'
            }`}
          >
            <div className="flex items-center">
              <Avatar 
                src={participant.avatarUrl} 
                name={participant.name} 
                size="xs" 
              />
              <span className="ml-2 text-sm font-medium">{participant.name}</span>
            </div>
            
            {multiplePayersMode === 'custom' && payerIds.includes(participant.userId) ? (
              <div className="flex items-center">
                <span className="mr-1 text-xs text-gray-600">₹</span>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  className="w-20 h-8 text-xs"
                  value={participant.paidAmount || ''}
                  onChange={(e) => handlePaidAmountChange(
                    participant.userId, 
                    parseFloat(e.target.value) || 0
                  )}
                />
              </div>
            ) : (
              <button
                type="button"
                onClick={() => handleAddPayer(participant.userId)}
                className={`p-1 rounded-full ${
                  payerIds.includes(participant.userId)
                    ? 'bg-green-100 text-green-700'
                    : 'bg-gray-100 text-gray-500'
                }`}
              >
                {payerIds.includes(participant.userId) ? 
                  <Check size={16} /> : 
                  <Plus size={16} />
                }
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
  
  const renderParticipantShares = () => (
    <div className="space-y-3 mt-4">
      <label className="block text-sm font-medium text-gray-700">Who's involved</label>
      
      {participants.map(participant => (
        <div 
          key={participant.userId} 
          className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg"
        >
          <Avatar
            src={participant.avatarUrl}
            name={participant.name}
            size="sm"
          />
          <div className="flex-1">
            <div className="text-sm font-medium">{participant.name}</div>
            {payerIds.includes(participant.userId) && (
              <div className="text-xs text-green-600">
                {multiplePayersMode === 'equal' && payerIds.length > 1 
                  ? `Paid ${(100 / payerIds.length).toFixed(0)}%` 
                  : participant.paidAmount > 0 
                    ? `Paid ₹${participant.paidAmount.toFixed(2)}` 
                    : 'Paid the bill'}
              </div>
            )}
          </div>
          
          {splitType === 'custom' ? (
            <div className="flex items-center">
              <span className="mr-1 text-xs text-gray-600">₹</span>
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                className="w-20"
                value={participant.shareAmount || ''}
                onChange={(e) => handleShareChange(
                  participant.userId, 
                  parseFloat(e.target.value) || 0,
                  'shareAmount'
                )}
              />
            </div>
          ) : splitType === 'percentage' ? (
            <div className="flex items-center w-20">
              <Input
                type="number"
                min="0"
                max="100"
                placeholder="0"
                className="w-14"
                value={participant.sharePercentage || ''}
                onChange={(e) => handlePercentageChange(
                  participant.userId, 
                  parseFloat(e.target.value) || 0
                )}
              />
              <span className="ml-1 text-gray-500">%</span>
            </div>
          ) : splitType === 'shares' ? (
            <div className="flex items-center w-24">
              <Input
                type="number"
                min="1"
                placeholder="1"
                className="w-16"
                value={participant.shares || ''}
                onChange={(e) => handleSharesChange(
                  participant.userId, 
                  parseInt(e.target.value) || 1
                )}
              />
              <span className="ml-1 text-xs text-gray-500">{totalShares > 0 ? 
                `(${((participant.shares || 1) / totalShares * 100).toFixed(0)}%)` : 
                ''}</span>
            </div>
          ) : (
            <div className="text-sm font-medium w-24 text-right">
              ₹{participant.shareAmount.toFixed(2)}
            </div>
          )}
        </div>
      ))}
    </div>
  );
  
  return (
    <form className="space-y-4" onSubmit={handleSubmit}>
      {step === 1 ? (
        <motion.div
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -10 }}
          className="space-y-5"
        >
          <div className="relative">
            <Input
              label="Amount"
              type="number"
              step="0.01"
              min="0"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              icon={<CreditCard size={18} className="text-gray-400" />}
              required
            />
            <div className="absolute left-10 top-[34px] text-gray-500 font-medium">₹</div>
          </div>
          
          <Input
            label="Description"
            type="text"
            placeholder="What was this expense for?"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
          
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">Split with</label>
            <div className="flex space-x-2 mb-3">
              <button
                type="button"
                onClick={() => {
                  setExpenseType('group');
                  setSelectedFriendId('');
                }}
                className={`flex-1 px-3 py-2 rounded-lg border ${
                  expenseType === 'group'
                    ? 'bg-primary-50 border-primary-300 text-primary-700'
                    : 'border-gray-300 text-gray-700'
                }`}
              >
                <Users size={16} className="mx-auto mb-1" />
                <div className="text-xs">Group</div>
              </button>
              <button
                type="button"
                onClick={() => {
                  setExpenseType('personal');
                  setSelectedGroupId('');
                }}
                className={`flex-1 px-3 py-2 rounded-lg border ${
                  expenseType === 'personal'
                    ? 'bg-primary-50 border-primary-300 text-primary-700'
                    : 'border-gray-300 text-gray-700'
                }`}
              >
                <User size={16} className="mx-auto mb-1" />
                <div className="text-xs">Friend</div>
              </button>
            </div>
            
            {expenseType === 'group' ? (
              <div className="space-y-2">
                <select
                  className="block w-full p-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-lg"
                  value={selectedGroupId}
                  onChange={(e) => setSelectedGroupId(e.target.value)}
                >
                  <option value="">Select a group</option>
                  {groups.map((group) => (
                    <option key={group.id} value={group.id}>{group.name}</option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="space-y-2">
                {selectedFriendId ? (
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <Avatar 
                        src={undefined} 
                        name={searchResults.find(u => u.id === selectedFriendId)?.name || 'Friend'} 
                        size="sm" 
                      />
                      <div className="ml-2">
                        <div className="text-sm font-medium">
                          {searchResults.find(u => u.id === selectedFriendId)?.name}
                        </div>
                        <div className="text-xs text-gray-500">
                          {searchResults.find(u => u.id === selectedFriendId)?.email}
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedFriendId('')}
                      className="p-1 rounded-full hover:bg-gray-200"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ) : (
                  <div>
                    <div className="relative">
                      <Input
                        placeholder="Search friends by name or email"
                        value={friendSearch}
                        onChange={(e) => handleSearchFriend(e.target.value)}
                        icon={<User size={18} />}
                      />
                    </div>
                    
                    {isSearching ? (
                      <div className="mt-2 text-center text-sm text-gray-500">
                        Searching...
                      </div>
                    ) : searchResults.length > 0 ? (
                      <div className="mt-2 border rounded-lg max-h-32 overflow-y-auto">
                        {searchResults.map(result => (
                          <button
                            key={result.id}
                            type="button"
                            onClick={() => setSelectedFriendId(result.id)}
                            className="flex items-center w-full p-2 hover:bg-gray-50 text-left"
                          >
                            <Avatar src={undefined} name={result.name} size="xs" />
                            <div className="ml-2">
                              <div className="text-sm font-medium">{result.name}</div>
                              <div className="text-xs text-gray-500">{result.email}</div>
                            </div>
                          </button>
                        ))}
                      </div>
                    ) : friendSearch.length >= 3 ? (
                      <div className="mt-2 text-center">
                        <p className="text-sm text-gray-500">No friends found</p>
                        <button
                          type="button"
                          onClick={() => setShowInviteForm(true)}
                          className="mt-1 text-xs text-primary-600 hover:text-primary-700"
                        >
                          Invite someone new
                        </button>
                      </div>
                    ) : null}
                    
                    {!selectedFriendId && !isSearching && (
                      <button
                        type="button"
                        onClick={() => setShowInviteForm(true)}
                        className="mt-3 w-full py-2 px-3 flex items-center justify-center text-sm border border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-700"
                      >
                        <UserPlus size={16} className="mr-1" />
                        Invite someone new
                      </button>
                    )}
                    
                    {showInviteForm && (
                      <div className="mt-3 p-3 border border-gray-200 rounded-lg">
                        <h4 className="text-sm font-medium mb-2">Invite a friend</h4>
                        <div className="space-y-3">
                          <Input
                            placeholder="Email address"
                            value={inviteEmail}
                            onChange={(e) => setInviteEmail(e.target.value)}
                            icon={<Mail size={16} />}
                            type="email"
                          />
                          <Input
                            placeholder="Phone number (optional)"
                            value={invitePhone}
                            onChange={(e) => setInvitePhone(e.target.value)}
                            type="tel"
                          />
                          <div className="flex space-x-2">
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => setShowInviteForm(false)}
                              className="flex-1"
                            >
                              Cancel
                            </Button>
                            <Button
                              type="button"
                              size="sm"
                              onClick={handleInviteFriend}
                              className="flex-1"
                            >
                              Send Invite
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
          
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">Category</label>
            <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto">
              {EXPENSE_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`flex flex-col items-center p-2 rounded-lg border ${
                    category === cat 
                      ? 'bg-primary-50 border-primary-300 text-primary-700' 
                      : 'border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <span className="text-lg mb-1">{getCategoryIcon(cat)}</span>
                  <span className="text-xs">{cat}</span>
                </button>
              ))}
            </div>
          </div>
          
          <Input
            label="Notes (optional)"
            type="text"
            placeholder="Add any additional details"
            value={notes || ''}
            onChange={(e) => setNotes(e.target.value)}
            icon={<FileText size={18} className="text-gray-400" />}
          />
          
          {error && (
            <div className="p-3 text-sm text-red-600 bg-red-50 rounded-lg border border-red-200">
              {error}
            </div>
          )}
          
          <div className="flex space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={handleNext}
              className="flex-1"
              rightIcon={<ArrowRight size={16} />}
            >
              Next
            </Button>
          </div>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -10 }}
          className="space-y-5"
        >
          <div className="bg-gradient-to-r from-primary-50 to-primary-100 p-3 rounded-lg shadow-sm">
            <div className="text-sm text-gray-500">Total amount</div>
            <div className="text-xl font-semibold">₹{parseFloat(amount || '0').toFixed(2)}</div>
            <div className="text-sm text-gray-500">
              {description} {category && <span className="ml-1">{getCategoryIcon(category)}</span>}
            </div>
          </div>
          
          {renderPayerSelector()}
          
          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700">Split type</label>
            {renderSplitTypeOptions()}
          </div>
          
          {renderParticipantShares()}
          
          {error && (
            <div className="p-3 text-sm text-red-600 bg-red-50 rounded-lg border border-red-200">
              {error}
            </div>
          )}
          
          <div className="flex space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleBack}
              className="flex-1"
              leftIcon={<ArrowLeft size={16} />}
            >
              Back
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="flex-1 bg-gradient-primary hover:opacity-90"
            >
              {expense ? 'Update' : 'Save'} Expense
            </Button>
          </div>
        </motion.div>
      )}
    </form>
  );
};

export default ExpenseForm;
 