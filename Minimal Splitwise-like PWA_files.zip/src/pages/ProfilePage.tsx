import  React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, MapPin, RefreshCw, Download, Moon, Sun, Bell, BellOff } from 'lucide-react';
import { useAuthStore } from '../store/auth-store';
import Button from '../components/ui/Button';
import Avatar from '../components/ui/Avatar';
import Input from '../components/ui/Input';

const ProfilePage: React.FC = () => {
  const { user } = useAuthStore();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [location, setLocation] = useState('New Delhi, India');
  const [loading, setLoading] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [currency, setCurrency] = useState('INR');
  
  const handleSaveProfile = async () => {
    setLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 800));
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    // In a real app, this would update the theme
  };
  
  const toggleNotifications = () => {
    setNotificationsEnabled(!notificationsEnabled);
    // In a real app, this would update notification settings
  };
  
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Your Profile</h1>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl shadow-sleek p-6 mb-6 border border-gray-100"
      >
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          <div className="relative">
            <Avatar
              name={user?.name || 'User'}
              src={user?.avatarUrl}
              size="xl"
            />
            {isEditing && (
              <button className="absolute bottom-0 right-0 bg-primary-600 text-white p-1 rounded-full shadow-md">
                <User size={14} />
              </button>
            )}
          </div>
          
          <div className="flex-1 space-y-4 text-center sm:text-left">
            {isEditing ? (
              <>
                <Input
                  label="Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  icon={<User size={18} className="text-gray-400" />}
                />
                
                <Input
                  label="Email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  icon={<Mail size={18} className="text-gray-400" />}
                />
                
                <Input
                  label="Location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  icon={<MapPin size={18} className="text-gray-400" />}
                />
                
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsEditing(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSaveProfile}
                    className="flex-1"
                    isLoading={loading}
                  >
                    Save Changes
                  </Button>
                </div>
              </>
            ) : (
              <>
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">{user?.name}</h2>
                  <p className="text-gray-500 flex items-center justify-center sm:justify-start mt-1">
                    <Mail size={16} className="mr-1" />
                    {user?.email}
                  </p>
                  <p className="text-gray-500 flex items-center justify-center sm:justify-start mt-1">
                    <MapPin size={16} className="mr-1" />
                    {location}
                  </p>
                </div>
                
                <Button
                  onClick={() => setIsEditing(true)}
                  variant="outline"
                >
                  Edit Profile
                </Button>
              </>
            )}
          </div>
        </div>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-xl shadow-sleek p-6 mb-6 border border-gray-100"
      >
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Settings</h2>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between py-3 border-b border-gray-100">
            <div className="flex items-center">
              {isDarkMode ? <Moon size={20} className="mr-3 text-gray-600" /> : <Sun size={20} className="mr-3 text-gray-600" />}
              <div>
                <p className="font-medium">Theme</p>
                <p className="text-sm text-gray-500">{isDarkMode ? 'Dark' : 'Light'} mode</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={toggleDarkMode}
            >
              {isDarkMode ? 'Light Mode' : 'Dark Mode'}
            </Button>
          </div>
          
          <div className="flex items-center justify-between py-3 border-b border-gray-100">
            <div className="flex items-center">
              {notificationsEnabled ? <Bell size={20} className="mr-3 text-gray-600" /> : <BellOff size={20} className="mr-3 text-gray-600" />}
              <div>
                <p className="font-medium">Notifications</p>
                <p className="text-sm text-gray-500">{notificationsEnabled ? 'Enabled' : 'Disabled'}</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={toggleNotifications}
            >
              {notificationsEnabled ? 'Disable' : 'Enable'}
            </Button>
          </div>
          
          <div className="flex items-center justify-between py-3 border-b border-gray-100">
            <div className="flex items-center">
              <RefreshCw size={20} className="mr-3 text-gray-600" />
              <div>
                <p className="font-medium">Currency</p>
                <p className="text-sm text-gray-500">Your default currency</p>
              </div>
            </div>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm"
            >
              <option value="INR">Indian Rupee (₹)</option>
              <option value="USD">US Dollar ($)</option>
              <option value="EUR">Euro (€)</option>
              <option value="GBP">British Pound (£)</option>
            </select>
          </div>
        </div>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-xl shadow-sleek p-6 mb-6 border border-gray-100"
      >
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Data</h2>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Download size={20} className="mr-3 text-gray-600" />
              <div>
                <p className="font-medium">Export Data</p>
                <p className="text-sm text-gray-500">Download all your expense data</p>
              </div>
            </div>
            <Button variant="outline" size="sm">
              Export CSV
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ProfilePage;
 