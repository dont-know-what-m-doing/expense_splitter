import  React, { useState } from 'react';
import { Mail, UserPlus, X, Phone } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Avatar from '../ui/Avatar';
import { Group, User } from '../../types';
import { useGroupStore } from '../../store/group-store';
import { searchUserByEmail } from '../../lib/supabase';

interface MemberManagementProps {
  group: Group;
  onClose: () => void;
}

const MemberManagement: React.FC<MemberManagementProps> = ({ group, onClose }) => {
  const { addMemberToGroup, removeMemberFromGroup, loading } = useGroupStore();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [error, setError] = useState('');
  const [showInviteForm, setShowInviteForm] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [invitePhone, setInvitePhone] = useState('');
  
  const handleSearch = async () => {
    if (!searchTerm || searchTerm.length < 3) {
      setError('Please enter at least 3 characters to search');
      return;
    }
    
    setError('');
    setSearchLoading(true);
    
    try {
      const { data, error } = await searchUserByEmail(searchTerm);
      
      if (error) {
        setError('Error searching for users');
        return;
      }
      
      // Filter out users who are already members
      const filteredResults = data
        .filter(user => !group.members?.some(member => member.id === user.id))
        .map(user => ({
          id: user.id,
          name: user.name,
          email: user.email,
          avatarUrl: user.avatar_url
        }));
      
      setSearchResults(filteredResults);
      
      if (filteredResults.length === 0) {
        setError('No users found matching your search');
      }
    } catch (error) {
      setError('An error occurred while searching');
    } finally {
      setSearchLoading(false);
    }
  };
  
  const handleInviteFriend = async () => {
    if (!inviteEmail && !invitePhone) {
      setError('Please enter an email or phone number');
      return;
    }
    
    if (inviteEmail && !inviteEmail.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }
    
    setError('');
    // In a real app, this would send an invitation
    
    alert(`Invitation sent to ${inviteEmail || invitePhone}`);
    setInviteEmail('');
    setInvitePhone('');
    setShowInviteForm(false);
  };
  
  const handleAddMember = async (userId: string) => {
    setError('');
    
    try {
      await addMemberToGroup(group.id, userId);
      // Clear search results after adding
      setSearchResults([]);
      setSearchTerm('');
    } catch (error: any) {
      setError(error.message || 'Failed to add member');
    }
  };
  
  const handleRemoveMember = async (userId: string) => {
    setError('');
    
    try {
      await removeMemberFromGroup(group.id, userId);
    } catch (error: any) {
      setError(error.message || 'Failed to remove member');
    }
  };
  
  return (
    <div className="space-y-4">
      <div className="mb-5">
        <div className="flex space-x-2 mb-3">
          <Input
            placeholder="Search users by email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Mail size={18} />}
            className="flex-1"
          />
          <Button 
            onClick={handleSearch} 
            disabled={searchLoading}
            isLoading={searchLoading}
          >
            Search
          </Button>
        </div>
        
        {error && (
          <div className="p-3 text-sm text-red-600 bg-red-50 rounded-lg border border-red-200">
            {error}
          </div>
        )}
        
        {searchResults.length > 0 && (
          <div className="space-y-2 mt-3 bg-gray-50 p-3 rounded-lg">
            <h4 className="text-sm font-medium text-gray-700">Search Results</h4>
            {searchResults.map(user => (
              <div 
                key={user.id} 
                className="flex items-center justify-between p-2 rounded-lg bg-white border border-gray-200"
              >
                <div className="flex items-center space-x-2">
                  <Avatar src={user.avatarUrl} name={user.name} size="sm" />
                  <div>
                    <div className="font-medium text-sm">{user.name}</div>
                    <div className="text-xs text-gray-500">{user.email}</div>
                  </div>
                </div>
                <Button
                  size="sm"
                  leftIcon={<UserPlus size={14} />}
                  onClick={() => handleAddMember(user.id)}
                  disabled={loading}
                >
                  Add
                </Button>
              </div>
            ))}
          </div>
        )}
        
        <button
          type="button"
          onClick={() => setShowInviteForm(!showInviteForm)}
          className="mt-3 w-full py-2 px-3 flex items-center justify-center text-sm border border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-700"
        >
          <UserPlus size={16} className="mr-1" />
          Invite someone new
        </button>
        
        {showInviteForm && (
          <div className="mt-3 p-3 border border-gray-200 rounded-lg">
            <h4 className="text-sm font-medium mb-2">Invite to group: {group.name}</h4>
            <div className="space-y-3">
              <Input
                placeholder="Email address"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                icon={<Mail size={16} />}
                type="email"
              />
              <Input
                placeholder="Phone number (optional)"
                value={invitePhone}
                onChange={(e) => setInvitePhone(e.target.value)}
                icon={<Phone size={16} />}
                type="tel"
              />
              <div className="flex space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setShowInviteForm(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  size="sm"
                  onClick={handleInviteFriend}
                  className="flex-1"
                >
                  Send Invite
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
      
      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">Current Members</h3>
        <div className="space-y-2">
          {group.members && group.members.length > 0 ? (
            group.members.map(member => (
              <div 
                key={member.id} 
                className="flex items-center justify-between p-3 rounded-lg bg-white border border-gray-200"
              >
                <div className="flex items-center space-x-3">
                  <Avatar src={member.avatarUrl} name={member.name} size="sm" />
                  <div>
                    <div className="font-medium">{member.name}</div>
                    <div className="text-xs text-gray-500">{member.email}</div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-red-600"
                  onClick={() => handleRemoveMember(member.id)}
                  leftIcon={<X size={14} />}
                  disabled={loading}
                >
                  Remove
                </Button>
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-center py-3">No members in this group</p>
          )}
        </div>
      </div>
      
      <div className="flex justify-end pt-4">
        <Button onClick={onClose}>Done</Button>
      </div>
    </div>
  );
};

export default MemberManagement;
 